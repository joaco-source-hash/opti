﻿# Comun.ps1 - Funciones compartidas por todos los scripts del Optimizador
# Uso: . (Join-Path $PSScriptRoot '..\lib\Comun.ps1')

$global:OptRaiz       = Split-Path -Parent $PSScriptRoot
$global:OptDatosDir   = Join-Path $global:OptRaiz 'datos'
foreach ($d in @($global:OptDatosDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

# ---------- Utilidades basicas ----------

$global:OptVersion = '2.0'
if (-not $global:OptContador) { $global:OptContador = @{ OK = 0; WARN = 0; ERROR = 0 } }

function Write-Log {
    # Solo pantalla (no se guarda ningun registro): formato limpio, con titulos de seccion.
    param(
        [string]$Mensaje,
        [ValidateSet('INFO', 'OK', 'WARN', 'ERROR')][string]$Nivel = 'INFO'
    )
    if ($global:OptContador.ContainsKey($Nivel)) { $global:OptContador[$Nivel]++ }

    if ($Mensaje -match '^=== (.+) ===$') {
        Write-Host ''
        Write-Host ("  >> " + $Matches[1]) -ForegroundColor Yellow
        Write-Host ('  ' + ('-' * 60)) -ForegroundColor DarkYellow
        return
    }
    switch ($Nivel) {
        'OK'    { Write-Host ("   [OK] " + $Mensaje) -ForegroundColor Green }
        'WARN'  { Write-Host ("   [!]  " + $Mensaje) -ForegroundColor Yellow }
        'ERROR' { Write-Host ("   [X]  " + $Mensaje) -ForegroundColor Red }
        default { Write-Host ("   [i]  " + $Mensaje) -ForegroundColor Gray }
    }
}

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Assert-Admin {
    if (-not (Test-Admin)) {
        Write-Log 'Este paso requiere ejecutar como Administrador. Use Iniciar.bat.' 'ERROR'
        return $false
    }
    return $true
}

function Confirm-Accion {
    param([string]$Pregunta)
    $r = Read-Host "$Pregunta (S/N)"
    return ($r -match '^[sS]')
}

# ---------- Carpetas ----------

function Get-FolderSizeMB {
    param([string]$Ruta)
    if (-not (Test-Path $Ruta)) { return 0 }
    $s = (Get-ChildItem -Path $Ruta -Recurse -Force -File -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum
    if (-not $s) { return 0 }
    return [math]::Round($s / 1MB, 1)
}

function Clear-Carpeta {
    # Vacia el contenido de una carpeta (no la carpeta). Devuelve MB liberados.
    param([string]$Ruta, [switch]$Simular)
    if (-not (Test-Path $Ruta)) { return 0 }
    $antes = Get-FolderSizeMB $Ruta
    if ($Simular) { return $antes }
    Get-ChildItem -Path $Ruta -Force -ErrorAction SilentlyContinue |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    $despues = Get-FolderSizeMB $Ruta
    return [math]::Round([math]::Max($antes - $despues, 0), 1)
}

# ---------- Arranque de Windows ----------

function Test-Aprobado {
    param([string]$Aprob, [string]$Nombre)
    if (-not (Test-Path $Aprob)) { return $true }
    $v = (Get-ItemProperty -Path $Aprob -Name $Nombre -ErrorAction SilentlyContinue).$Nombre
    if ($v -and $v.Count -gt 0 -and $v[0] -ne 2 -and $v[0] -ne 6) { return $false }
    return $true
}

function Get-StartupItems {
    $items = @()
    $base = 'Software\Microsoft\Windows\CurrentVersion'
    $claves = @(
        @{ Ruta = "HKCU:\$base\Run"; Aprob = "HKCU:\$base\Explorer\StartupApproved\Run"; Origen = 'Registro (usuario)' },
        @{ Ruta = "HKLM:\$base\Run"; Aprob = "HKLM:\$base\Explorer\StartupApproved\Run"; Origen = 'Registro (equipo)' }
    )
    foreach ($c in $claves) {
        if (Test-Path $c.Ruta) {
            $props = (Get-Item $c.Ruta).Property
            foreach ($n in $props) {
                $cmd = (Get-ItemProperty -Path $c.Ruta -Name $n -ErrorAction SilentlyContinue).$n
                $items += [pscustomobject]@{
                    Nombre = $n; Comando = $cmd; Origen = $c.Origen; Aprob = $c.Aprob
                    Habilitado = (Test-Aprobado $c.Aprob $n)
                }
            }
        }
    }
    $carpetas = @(
        @{ Ruta = "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"; Aprob = "HKCU:\$base\Explorer\StartupApproved\StartupFolder"; Origen = 'Carpeta Inicio (usuario)' },
        @{ Ruta = "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Startup"; Aprob = "HKLM:\$base\Explorer\StartupApproved\StartupFolder"; Origen = 'Carpeta Inicio (todos)' }
    )
    foreach ($c in $carpetas) {
        if (Test-Path $c.Ruta) {
            Get-ChildItem -Path $c.Ruta -File -Force -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -ne 'desktop.ini' } | ForEach-Object {
                    $items += [pscustomobject]@{
                        Nombre = $_.Name; Comando = $_.FullName; Origen = $c.Origen; Aprob = $c.Aprob
                        Habilitado = (Test-Aprobado $c.Aprob $_.Name)
                    }
                }
        }
    }
    return $items
}

function Set-StartupState {
    param($Item, [bool]$Habilitar)
    if (-not (Test-Path $Item.Aprob)) { New-Item -Path $Item.Aprob -Force | Out-Null }
    if ($Habilitar) { $bytes = [byte[]](2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0) }
    else            { $bytes = [byte[]](3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0) }
    Set-ItemProperty -Path $Item.Aprob -Name $Item.Nombre -Value $bytes -Type Binary -ErrorAction Stop
}

# ---------- Registro con backup (para poder revertir) ----------

$global:OptCentral = Join-Path $global:OptDatosDir 'original_registro.json'

function Get-OriginalesCentral {
    # Valores originales (antes de cualquier modo) indexados por "ruta|nombre"
    $h = @{}
    if (Test-Path $global:OptCentral) {
        try {
            $tmp = Get-Content $global:OptCentral -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($i in @($tmp)) { $h["$($i.Ruta)|$($i.Nombre)"] = $i }
        } catch { }
    }
    return $h
}

function Save-OriginalesCentral {
    param($Tabla)
    $lista = @($Tabla.Values)
    if ($lista.Count -eq 0) { Remove-Item $global:OptCentral -Force -ErrorAction SilentlyContinue; return }
    ConvertTo-Json -InputObject $lista -Depth 5 | Set-Content -Path $global:OptCentral -Encoding UTF8
}

function Set-RegistroConBackup {
    # $Cambios: array de @{Ruta=;Nombre=;Valor=;Tipo=}.
    # Cada archivo de backup guarda el valor ORIGINAL de Windows (aunque otro modo ya lo haya cambiado),
    # asi se puede revertir en cualquier orden.
    param([array]$Cambios, [string]$ArchivoBackup, [switch]$Resumen)
    $backup = @()
    $aplicados = 0
    $central = Get-OriginalesCentral
    foreach ($c in $Cambios) {
        try {
            if (-not (Test-Path $c.Ruta)) { New-Item -Path $c.Ruta -Force | Out-Null }
            $clave = "$($c.Ruta)|$($c.Nombre)"
            if ($central.ContainsKey($clave)) {
                $o = $central[$clave]
                $backup += [pscustomobject]@{ Ruta = $c.Ruta; Nombre = $c.Nombre; Existia = $o.Existia; Valor = $o.Valor; Tipo = $o.Tipo }
            } else {
                $prev = Get-ItemProperty -Path $c.Ruta -Name $c.Nombre -ErrorAction SilentlyContinue
                $existia = ($null -ne $prev)
                $valorPrev = $null
                if ($existia) { $valorPrev = $prev.($c.Nombre) }
                $reg = [pscustomobject]@{ Ruta = $c.Ruta; Nombre = $c.Nombre; Existia = $existia; Valor = $valorPrev; Tipo = $c.Tipo }
                $central[$clave] = $reg
                $backup += $reg
            }
            Set-ItemProperty -Path $c.Ruta -Name $c.Nombre -Value $c.Valor -Type $c.Tipo -Force -ErrorAction Stop
            if ($Resumen) { $aplicados++ } else { Write-Log "Ajustado: $($c.Nombre)" 'OK' }
        } catch {
            Write-Log "No se pudo ajustar $($c.Nombre): $($_.Exception.Message)" 'WARN'
        }
    }
    if ($Resumen) { Write-Log "Ajustes de registro aplicados: $aplicados" 'OK' }
    Save-OriginalesCentral $central
    $ruta = Join-Path $global:OptDatosDir $ArchivoBackup
    if ((-not (Test-Path $ruta)) -and $backup.Count -gt 0) {
        ConvertTo-Json -InputObject $backup -Depth 5 | Set-Content -Path $ruta -Encoding UTF8
    }
}

function Restore-RegistroDesdeBackup {
    param([string]$ArchivoBackup)
    $ruta = Join-Path $global:OptDatosDir $ArchivoBackup
    if (-not (Test-Path $ruta)) {
        Write-Log "No hay backup para revertir ($ArchivoBackup)." 'WARN'
        return
    }
    $items = Get-Content $ruta -Raw -Encoding UTF8 | ConvertFrom-Json
    $central = Get-OriginalesCentral
    foreach ($i in @($items)) {
        try {
            $val = $i.Valor
            if ($i.Tipo -eq 'Binary') { $val = [byte[]]$val }
            if ($i.Existia) { Set-ItemProperty -Path $i.Ruta -Name $i.Nombre -Value $val -Type $i.Tipo -Force -ErrorAction Stop }
            else            { Remove-ItemProperty -Path $i.Ruta -Name $i.Nombre -ErrorAction SilentlyContinue }
            $central.Remove("$($i.Ruta)|$($i.Nombre)")
            Write-Log "Restaurado: $($i.Nombre)" 'OK'
        } catch {
            Write-Log "No se pudo restaurar $($i.Nombre): $($_.Exception.Message)" 'WARN'
        }
    }
    Save-OriginalesCentral $central
    Remove-Item $ruta -Force -ErrorAction SilentlyContinue
}

# ---------- Restauracion del sistema ----------

function New-PuntoRestauracion {
    # Crea un punto de restauracion. Se levanta temporalmente el limite de uno cada 24 h de Windows.
    $clave = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\SystemRestore'
    $nombre = 'SystemRestorePointCreationFrequency'
    $previo = (Get-ItemProperty -Path $clave -Name $nombre -ErrorAction SilentlyContinue).$nombre
    try {
        Enable-ComputerRestore -Drive "$($env:SystemDrive)\" -ErrorAction SilentlyContinue
        Set-ItemProperty -Path $clave -Name $nombre -Value 0 -Type DWord -Force -ErrorAction SilentlyContinue
        Write-Log 'Creando punto de restauracion (puede tardar un minuto)...'
        Checkpoint-Computer -Description 'PC Optimizer - antes de cambios' -RestorePointType MODIFY_SETTINGS -ErrorAction Stop
        Write-Log 'Punto de restauracion creado.' 'OK'
    } catch {
        Write-Log "No se pudo crear el punto de restauracion: $($_.Exception.Message)" 'WARN'
    } finally {
        if ($null -ne $previo) { Set-ItemProperty -Path $clave -Name $nombre -Value $previo -Type DWord -Force -ErrorAction SilentlyContinue }
        else { Remove-ItemProperty -Path $clave -Name $nombre -ErrorAction SilentlyContinue }
    }
}

# ---------- Ayudas compartidas por los modos de optimizacion ----------

function RegVal {
    param($Ruta, $Nombre, $Valor, $Tipo = 'DWord')
    return @{ Ruta = $Ruta; Nombre = $Nombre; Valor = $Valor; Tipo = $Tipo }
}

function Get-TipoDisco {
    try {
        $letra = $env:SystemDrive.Substring(0, 1)
        $pd = Get-Partition -DriveLetter $letra -ErrorAction Stop | Get-Disk | Get-PhysicalDisk -ErrorAction Stop
        return [string]$pd.MediaType
    } catch { return 'Desconocido' }
}

function Get-ListaJuegos {
    # Lee lista-juegos.txt (un .exe por linea). Solo acepta nombres simples de archivo.
    $ruta = Join-Path $global:OptRaiz 'lista-juegos.txt'
    $res = @()
    if (Test-Path $ruta) {
        foreach ($l in @(Get-Content $ruta -Encoding UTF8)) {
            $t = $l.Trim()
            if ($t -and (-not $t.StartsWith('#')) -and ($t -match '^[\w\.\-\+ ]+\.exe$')) { $res += $t }
        }
    }
    return $res
}

function Get-TiempoArranque {
    # Duracion del ultimo arranque en segundos (evento 100 de Diagnostics-Performance). $null si no hay dato.
    try {
        $ev = Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-Diagnostics-Performance/Operational'; Id = 100 } -MaxEvents 1 -ErrorAction Stop
        $xml = [xml]$ev.ToXml()
        $d = @($xml.Event.EventData.Data | Where-Object { $_.Name -eq 'BootTime' }) | Select-Object -First 1
        if ($d) { return [int][math]::Round([double]$d.'#text' / 1000, 0) }
    } catch { }
    return $null
}

# ---------- Servicios con backup (3 = manual, 4 = deshabilitado, 5 = automatico retrasado) ----------

$global:OptBkServiciosBase = 'backup_ajustes_servicios.json'

function Save-BackupServicios {
    param([array]$Nuevos, [string]$Archivo = $global:OptBkServiciosBase)
    if ($Nuevos.Count -eq 0) { return }
    $ruta = Join-Path $global:OptDatosDir $Archivo
    $existentes = @()
    if (Test-Path $ruta) {
        $tmp = Get-Content $ruta -Raw -Encoding UTF8 | ConvertFrom-Json
        $existentes = @($tmp)
    }
    $todos = @($existentes)
    foreach ($n in $Nuevos) {
        if (-not ($existentes | Where-Object { $_.Nombre -eq $n.Nombre })) { $todos += $n }
    }
    ConvertTo-Json -InputObject @($todos) | Set-Content -Path $ruta -Encoding UTF8
}

function Set-ServiciosInicio {
    # Lista de @{N=nombre; S=3|4|5; SoloAuto=$true para tocar solo los que hoy son Automaticos}
    param([array]$Lista, [string]$Archivo = $global:OptBkServiciosBase)
    $nuevos = @()
    foreach ($s in $Lista) {
        $nom = $s.N
        $k = "HKLM:\SYSTEM\CurrentControlSet\Services\$nom"
        if (-not (Test-Path $k)) { continue }
        try {
            $p = Get-ItemProperty -Path $k
            $actual = [int]$p.Start
            if ($actual -lt 2) { continue }
            if ($s.S -eq 5) {
                if ($actual -ne 2 -or $p.DelayedAutostart -eq 1) { continue }
                $modo = 'delayed-auto'
            } else {
                if ($s.SoloAuto -and $actual -ne 2) { continue }
                if ($actual -eq $s.S) { continue }
                # Un servicio que ya estaba deshabilitado (por el usuario u otra optimizacion) no se vuelve a habilitar
                if ($s.S -eq 3 -and $actual -eq 4) { continue }
                if ($s.S -eq 4) { $modo = 'disabled' } else { $modo = 'demand' }
            }
            $nuevos += [pscustomobject]@{ Nombre = $nom; Start = $actual; Delayed = $p.DelayedAutostart }
            sc.exe config $nom start= $modo | Out-Null
            if ($s.S -eq 4) { Stop-Service -Name $nom -Force -ErrorAction SilentlyContinue }
            Write-Log "Servicio ${nom}: $modo" 'OK'
        } catch { Write-Log "No se pudo configurar el servicio ${nom}: $($_.Exception.Message)" 'WARN' }
    }
    Save-BackupServicios -Nuevos $nuevos -Archivo $Archivo
}

function Restore-ServiciosDesdeBackup {
    param([string]$Archivo = $global:OptBkServiciosBase)
    $ruta = Join-Path $global:OptDatosDir $Archivo
    if (-not (Test-Path $ruta)) { return }
    $lista = Get-Content $ruta -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($s in @($lista)) {
        $modo = $null
        if ($s.Start -eq 2) { if ($s.Delayed -eq 1) { $modo = 'delayed-auto' } else { $modo = 'auto' } }
        elseif ($s.Start -eq 3) { $modo = 'demand' }
        elseif ($s.Start -eq 4) { $modo = 'disabled' }
        if ($modo) {
            $nomSvc = $s.Nombre
            sc.exe config $nomSvc start= $modo | Out-Null
            Write-Log "Servicio $($s.Nombre) restaurado ($modo)" 'OK'
        }
    }
    Remove-Item $ruta -Force -ErrorAction SilentlyContinue
}

function Disable-TareasProgramadas {
    # Lista de rutas completas de tareas. Guarda las que desactiva para poder reactivarlas.
    param([string[]]$Tareas, [string]$Archivo)
    $bk = @()
    foreach ($t in $Tareas) {
        $i = $t.LastIndexOf('\')
        $ruta = $t.Substring(0, $i + 1)
        $nombre = $t.Substring($i + 1)
        $obj = Get-ScheduledTask -TaskPath $ruta -TaskName $nombre -ErrorAction SilentlyContinue
        if ($obj -and $obj.State -ne 'Disabled') {
            try {
                Disable-ScheduledTask -TaskPath $ruta -TaskName $nombre -ErrorAction Stop | Out-Null
                $bk += [pscustomobject]@{ Ruta = $ruta; Nombre = $nombre }
                Write-Log "Tarea desactivada: $nombre" 'OK'
            } catch { Write-Log "No se pudo desactivar la tarea $nombre" 'WARN' }
        }
    }
    $rutaBk = Join-Path $global:OptDatosDir $Archivo
    if ($bk.Count -gt 0 -and -not (Test-Path $rutaBk)) {
        ConvertTo-Json -InputObject @($bk) | Set-Content -Path $rutaBk -Encoding UTF8
    }
}

function Restore-TareasDesdeBackup {
    param([string]$Archivo = 'backup_ajustes_tareas.json')
    $ruta = Join-Path $global:OptDatosDir $Archivo
    if (-not (Test-Path $ruta)) { return }
    $lista = Get-Content $ruta -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($t in @($lista)) {
        try {
            Enable-ScheduledTask -TaskPath $t.Ruta -TaskName $t.Nombre -ErrorAction Stop | Out-Null
            Write-Log "Tarea reactivada: $($t.Nombre)" 'OK'
        } catch { Write-Log "No se pudo reactivar $($t.Nombre)" 'WARN' }
    }
    Remove-Item $ruta -Force -ErrorAction SilentlyContinue
}

function Restore-MemoriaDesdeBackup {
    # El archivo guarda si la compresion de memoria estaba activa antes de los cambios (True / False)
    $ruta = Join-Path $global:OptDatosDir 'backup_ajustes_memoria.txt'
    if (-not (Test-Path $ruta)) { return }
    $estado = (Get-Content $ruta -Encoding UTF8 | Select-Object -First 1)
    try {
        if ($estado -eq 'True') { Enable-MMAgent -MemoryCompression -ErrorAction Stop; Write-Log 'Compresion de memoria reactivada.' 'OK' }
        elseif ($estado -eq 'False') { Disable-MMAgent -MemoryCompression -ErrorAction Stop; Write-Log 'Compresion de memoria restaurada (desactivada).' 'OK' }
    } catch { Write-Log 'No se pudo restaurar la compresion de memoria.' 'WARN' }
    Remove-Item $ruta -Force -ErrorAction SilentlyContinue
}

# ---------- Programas de inicio por nombre (reversible con 03-Inicio.ps1 -Revertir) ----------

# Nunca se tocan: seguridad, audio, touchpad, bluetooth, teclado
$global:InicioProtegido = @(
    'SecurityHealth', 'Defender', 'Windows Security', 'Realtek', 'Rtk', 'Synaptics', 'ELAN', 'Touchpad',
    'Bluetooth', 'Avast', 'AVG', 'Avira', 'Kaspersky', 'ESET', 'Norton', 'McAfee', 'Bitdefender',
    'Malwarebytes', 'Sophos', 'ctfmon'
)
# Arranque rapido: solo lo que casi nunca hace falta al iniciar
$global:InicioSuave = @(
    'OneDrive', 'Teams', 'Skype', 'Spotify', 'Discord', 'Steam', 'EpicGames', 'Epic Games', 'EADesktop',
    'Origin', 'Battle.net', 'Ubisoft', 'Uplay', 'GalaxyClient', 'Adobe', 'AcroTray', 'CCXProcess',
    'jusched', 'Java', 'iTunes', 'Zoom', 'Dropbox', 'YourPhone', 'PhoneLink', 'Cortana'
)
# Reducir procesos al maximo: lo anterior mas actualizadores y mensajeria
$global:InicioMaximo = @($global:InicioSuave) + @(
    'GoogleUpdate', 'Google Update', 'MicrosoftEdgeAutoLaunch', 'GoogleChromeAutoLaunch', 'OneNote', 'Telegram',
    'WhatsApp', 'Slack', 'Viber', 'uTorrent', 'BitTorrent', 'qBittorrent', 'Overwolf', 'CCleaner', 'OpenVPN-GUI'
)

function Disable-InicioPorPatron {
    # Desactiva los programas de inicio cuyo nombre o comando contenga alguno de los patrones.
    # Guarda el estado original en backup_inicio.json (el mismo formato que usa 03-Inicio.ps1).
    param([string[]]$Patrones)
    $archivo = Join-Path $global:OptDatosDir 'backup_inicio.json'
    $resp = @()
    if (Test-Path $archivo) {
        $tmp = Get-Content $archivo -Raw -Encoding UTF8 | ConvertFrom-Json
        $resp = @($tmp)
    }
    $n = 0
    foreach ($it in @(Get-StartupItems)) {
        if (-not $it.Habilitado) { continue }
        $txt = "$($it.Nombre) $($it.Comando)"
        $coincide = $false
        foreach ($p in $Patrones) { if ($txt -like "*$p*") { $coincide = $true; break } }
        if (-not $coincide) { continue }
        foreach ($prot in $global:InicioProtegido) { if ($txt -like "*$prot*") { $coincide = $false; break } }
        if (-not $coincide) { continue }
        try {
            if (-not ($resp | Where-Object { $_.Nombre -eq $it.Nombre -and $_.Aprob -eq $it.Aprob })) {
                $resp += [pscustomobject]@{ Nombre = $it.Nombre; Aprob = $it.Aprob; HabilitadoOriginal = $true }
            }
            Set-StartupState -Item $it -Habilitar $false
            ConvertTo-Json -InputObject @($resp) | Set-Content -Path $archivo -Encoding UTF8
            Write-Log "Inicio desactivado: $($it.Nombre)" 'OK'
            $n++
        } catch { Write-Log "No se pudo desactivar $($it.Nombre): $($_.Exception.Message)" 'WARN' }
    }
    return $n
}

# ---------- Red ----------

function Get-Latencia {
    try {
        $p = New-Object System.Net.NetworkInformation.Ping
        $t = @()
        1..4 | ForEach-Object {
            $r = $p.Send('8.8.8.8', 2000)
            if ($r.Status -eq 'Success') { $t += $r.RoundtripTime }
        }
        if ($t.Count -gt 0) { return [math]::Round(($t | Measure-Object -Average).Average, 0) }
    } catch { }
    return $null
}
