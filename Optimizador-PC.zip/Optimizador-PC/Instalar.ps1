# Instalar.ps1 - Descarga y ejecuta PC Optimizer con un solo comando (repositorio privado o publico)
#
# Uso (PowerShell), con un repositorio PRIVADO y un token de solo lectura:
#   $Token='github_pat_XXXX'; irm -Headers @{Authorization="Bearer $Token";Accept='application/vnd.github.raw'} 'https://api.github.com/repos/TU-USUARIO/TU-REPOSITORIO/contents/Instalar.ps1?ref=main' | iex
#
# Edite $Usuario y $Repo con los datos de SU repositorio.
# Este archivo debe guardarse como texto simple (ASCII), sin BOM.
# El token no se guarda en el equipo del cliente.

$Usuario = 'TU-USUARIO'
$Repo    = 'TU-REPOSITORIO'
$Rama    = 'main'

# ---------------------------------------------------------------------------

$ErrorActionPreference = 'Stop'
$Api       = "https://api.github.com/repos/$Usuario/$Repo"
$UrlScript = "$Api/contents/Instalar.ps1?ref=$Rama"
$UrlZip    = "$Api/zipball/$Rama"
$Destino   = Join-Path $env:ProgramData 'PCOptimizer'

function Test-EsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

Write-Host ''
Write-Host '  PC OPTIMIZER' -ForegroundColor Yellow
Write-Host ''

if ($Usuario -eq 'TU-USUARIO' -or $Repo -eq 'TU-REPOSITORIO') {
    Write-Host '  Falta configurar Instalar.ps1: edite $Usuario y $Repo con los de su GitHub.' -ForegroundColor Red
    return
}

# 1) Permisos de Administrador: se vuelve a lanzar a si mismo elevado (el token viaja codificado, no se guarda)
if (-not (Test-EsAdmin)) {
    Write-Host '  Solicitando permisos de Administrador...' -ForegroundColor Gray
    if ($Token) {
        $hdr = '@{Authorization="Bearer $Token";Accept="application/vnd.github.raw"}'
        $orden = "`$Token='$Token'; irm -Headers $hdr '$UrlScript' | iex"
    } else {
        $orden = "irm -Headers @{Accept='application/vnd.github.raw'} '$UrlScript' | iex"
    }
    $codificado = [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($orden))
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList "-NoProfile -ExecutionPolicy Bypass -EncodedCommand $codificado"
    return
}

# 2) Si se ejecuta desde la carpeta del kit (copia local), se abre el menu directamente
if ($PSScriptRoot -and (Test-Path (Join-Path $PSScriptRoot 'Menu.ps1'))) {
    & powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Menu.ps1')
    return
}

# 3) Descarga del kit
try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $tmp = Join-Path $env:TEMP ('pcopt_' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tmp -Force | Out-Null
    $zip = Join-Path $tmp 'kit.zip'

    $cab = @{ 'User-Agent' = 'PCOptimizer'; 'Accept' = 'application/vnd.github+json' }
    if ($Token) { $cab['Authorization'] = "Bearer $Token" }

    Write-Host '  Descargando...' -ForegroundColor Gray
    # GitHub responde con una redireccion firmada: se sigue a mano para no reenviar el token al destino
    $destinoZip = $null
    try {
        Invoke-WebRequest -Uri $UrlZip -Headers $cab -MaximumRedirection 0 -UseBasicParsing -ErrorAction Stop | Out-Null
    } catch {
        $resp = $_.Exception.Response
        if ($resp) {
            try { $destinoZip = [string]$resp.Headers['Location'] } catch { }
            if (-not $destinoZip) { try { $destinoZip = [string]$resp.Headers.Location } catch { } }
        }
        if (-not $destinoZip) {
            $codigo = ''
            if ($resp) { $codigo = [int]$resp.StatusCode }
            if ($codigo -eq 401 -or $codigo -eq 403 -or $codigo -eq 404) {
                throw "GitHub rechazo el acceso ($codigo). Revise el token, que no haya vencido y que tenga permiso de lectura sobre $Usuario/$Repo."
            }
            throw $_
        }
    }
    if (-not $destinoZip) { throw 'GitHub no devolvio la descarga esperada.' }
    Invoke-WebRequest -Uri $destinoZip -OutFile $zip -UseBasicParsing

    Expand-Archive -Path $zip -DestinationPath (Join-Path $tmp 'x') -Force
    $menu = Get-ChildItem -Path (Join-Path $tmp 'x') -Recurse -Filter 'Menu.ps1' | Select-Object -First 1
    if (-not $menu) { throw 'El repositorio no contiene Menu.ps1.' }

    # 4) Instalacion en ProgramData (se conserva datos: son los backups para revertir)
    New-Item -ItemType Directory -Path $Destino -Force | Out-Null
    foreach ($carpeta in @('scripts', 'lib')) {
        Remove-Item -Path (Join-Path $Destino $carpeta) -Recurse -Force -ErrorAction SilentlyContinue
    }
    Get-ChildItem -Path $menu.DirectoryName -Force |
        Where-Object { $_.Name -notin @('datos', '.git', '.github') } |
        ForEach-Object { Copy-Item -Path $_.FullName -Destination $Destino -Recurse -Force }
    Remove-Item -Path $tmp -Recurse -Force -ErrorAction SilentlyContinue
}
catch {
    Write-Host ("  No se pudo descargar o instalar: " + $_.Exception.Message) -ForegroundColor Red
    return
}

# 5) Abrir el menu
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Destino 'Menu.ps1')
