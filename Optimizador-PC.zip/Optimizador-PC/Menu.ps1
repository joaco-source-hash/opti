﻿# Menu.ps1 - Menu principal del Optimizador de PC
$ErrorActionPreference = 'Continue'
. (Join-Path $PSScriptRoot 'lib\Comun.ps1')
Get-ChildItem -Path $PSScriptRoot -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
$Host.UI.RawUI.WindowTitle = 'PC Optimizer'

function Pausa { Write-Host ''; Read-Host '  Presione Enter para volver al menu' | Out-Null }

function Ejecutar {
    param([string]$Script, [hashtable]$Params = @{})
    try { & (Join-Path $PSScriptRoot "scripts\$Script") @Params }
    catch { Write-Log "Error en ${Script}: $($_.Exception.Message)" 'ERROR' }
}

function Get-InfoEquipo {
    $o = Get-CimInstance Win32_OperatingSystem -ErrorAction SilentlyContinue
    $c = Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue | Select-Object -First 1
    $cs = Get-CimInstance Win32_ComputerSystem -ErrorAction SilentlyContinue
    $d = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($env:SystemDrive)'" -ErrorAction SilentlyContinue
    $so = 'Windows'; if ($o) { $so = ("{0} (build {1})" -f ($o.Caption -replace 'Microsoft ', ''), $o.BuildNumber) }
    $cpu = ''; if ($c) { $cpu = ($c.Name -replace '\s+', ' ').Trim() }
    $ram = ''; if ($cs) { $ram = ("{0} GB" -f [math]::Round($cs.TotalPhysicalMemory / 1GB)) }
    $libre = ''; if ($d) { $libre = ("{0} GB libres de {1} GB" -f [math]::Round($d.FreeSpace / 1GB), [math]::Round($d.Size / 1GB)) }
    return [pscustomobject]@{ Equipo = $env:COMPUTERNAME; SO = $so; CPU = $cpu; RAM = $ram; Disco = (Get-TipoDisco); Libre = $libre }
}

$infoEquipo = Get-InfoEquipo

function Show-Cabecera {
    Clear-Host
    $linea = '=' * 64
    Write-Host ''
    Write-Host "  $linea" -ForegroundColor Yellow
    Write-Host ("   PC OPTIMIZER" + (' ' * 40) + "v$($global:OptVersion)") -ForegroundColor Yellow
    Write-Host "  $linea" -ForegroundColor Yellow
    Write-Host ("   Equipo : {0}   |   {1}" -f $infoEquipo.Equipo, $infoEquipo.SO) -ForegroundColor Gray
    Write-Host ("   CPU    : {0}" -f $infoEquipo.CPU) -ForegroundColor Gray
    Write-Host ("   RAM    : {0}   |   Disco: {1} ({2})" -f $infoEquipo.RAM, $infoEquipo.Disco, $infoEquipo.Libre) -ForegroundColor Gray
    Write-Host ('  ' + ('-' * 64)) -ForegroundColor DarkYellow
    if (-not (Test-Admin)) {
        Write-Host '   ATENCION: sin permisos de Administrador. Abra el programa con Iniciar.bat' -ForegroundColor Red
        Write-Host ('  ' + ('-' * 64)) -ForegroundColor DarkYellow
    }
}

function Show-Opcion {
    param([string]$Numero, [string]$Texto, [string]$Detalle = '')
    Write-Host ("    [{0}]  " -f $Numero) -NoNewline -ForegroundColor Yellow
    Write-Host $Texto -NoNewline -ForegroundColor White
    if ($Detalle) { Write-Host ("  - $Detalle") -ForegroundColor DarkGray } else { Write-Host '' }
}

function Show-Seccion { param([string]$Texto) Write-Host ''; Write-Host "   $Texto" -ForegroundColor Cyan }

function Show-Resumen {
    # Resultado del ultimo proceso, basado en el registro
    $c = $global:OptContador
    Write-Host ''
    Write-Host ('  ' + ('-' * 64)) -ForegroundColor DarkYellow
    $color = 'Green'; if ($c.ERROR -gt 0) { $color = 'Red' } elseif ($c.WARN -gt 0) { $color = 'Yellow' }
    Write-Host ("   Resultado: {0} cambios correctos, {1} avisos, {2} errores" -f $c.OK, $c.WARN, $c.ERROR) -ForegroundColor $color
}

function Ofrecer-Reinicio {
    Write-Host ''
    Write-Host '   Para completar los cambios hay que reiniciar el equipo.' -ForegroundColor Yellow
    if (Confirm-Accion '   Reiniciar ahora?') {
        Write-Log 'Reinicio programado en 15 segundos.' 'INFO'
        shutdown /r /t 15 /c "PC Optimizer: reinicio para completar los cambios" | Out-Null
        Write-Host '   Para cancelar el reinicio escriba: shutdown /a' -ForegroundColor DarkGray
    }
}

function Invoke-Modo {
    # Ejecuta un modo con resumen final y, si hace falta, ofrece reiniciar
    param([scriptblock]$Accion, [switch]$Reinicio)
    $global:OptContador = @{ OK = 0; WARN = 0; ERROR = 0 }
    & $Accion
    Show-Resumen
    if ($Reinicio) { Ofrecer-Reinicio }
    Pausa
}

function Invoke-OptimizacionCompleta {
    Write-Host ''
    Write-Host '   La optimizacion completa incluye: limpieza, optimizaciones de Windows, modo juegos, red,' -ForegroundColor Yellow
    Write-Host '   arranque rapido, reduccion de procesos y reduccion del consumo de RAM.' -ForegroundColor Yellow
    Write-Host ''
    Write-Host '   Opcional: quitar las apps preinstaladas innecesarias de la Tienda (no se pueden revertir' -ForegroundColor Yellow
    Write-Host '   desde este programa; se reinstalan desde Microsoft Store). Todo lo demas es reversible.' -ForegroundColor Yellow
    $avanzado = Confirm-Accion '   Quitar tambien las apps preinstaladas?'

    Write-Log '=== OPTIMIZACION COMPLETA ==='
    Ejecutar '01-Limpieza.ps1' @{ Silencioso = $true }
    Ejecutar '02-Rendimiento.ps1' @{ Silencioso = $true }
    Ejecutar '14-Optimizaciones-Windows.ps1' @{ SinJuegos = $true }
    Ejecutar '11-Modo-Juegos.ps1'
    Ejecutar '04-Red.ps1' @{ Silencioso = $true }
    Ejecutar '08-Ajustes-Avanzados.ps1' @{ Avanzado = [bool]$avanzado }
    Ejecutar '12-Arranque-Rapido.ps1'
    # Reducir RAM incluye reducir procesos al maximo y libera memoria al final
    Ejecutar '10-Reducir-RAM.ps1'
    Write-Log 'Optimizacion completa finalizada.' 'OK'
}

function Invoke-ReversionTotal {
    # Los modos posteriores se deshacen primero
    Ejecutar '12-Arranque-Rapido.ps1' @{ Revertir = $true }
    Ejecutar '10-Reducir-RAM.ps1' @{ Revertir = $true }
    Ejecutar '09-Reducir-Procesos.ps1' @{ Revertir = $true }
    Ejecutar '14-Optimizaciones-Windows.ps1' @{ Revertir = $true }
    Ejecutar '11-Modo-Juegos.ps1' @{ Revertir = $true }
    Ejecutar '08-Ajustes-Avanzados.ps1' @{ Revertir = $true }
    Ejecutar '03-Inicio.ps1' @{ Revertir = $true }
    Ejecutar '15-Plan-Energia.ps1' @{ Revertir = $true }
    Ejecutar '02-Rendimiento.ps1' @{ Revertir = $true }
    Write-Log 'Reversion terminada.' 'OK'
}

while ($true) {
    Show-Cabecera
    Show-Seccion 'OPTIMIZACION'
    Show-Opcion '1' 'Optimizacion completa' 'todo incluido: procesos, RAM, juegos, arranque'
    Show-Opcion '2' 'Optimizaciones de Windows' 'efectos, servicios, disco, tareas'
    Show-Opcion '3' 'Plan de energia Maximo rendimiento' 'crea y activa el plan'
    Show-Seccion 'MANTENIMIENTO'
    Show-Opcion '4' 'Limpieza profunda de disco'
    Show-Opcion '5' 'Reparar sistema' 'SFC / DISM / disco'
    Show-Seccion 'SEGURIDAD'
    Show-Opcion '6' 'Crear punto de restauracion'
    Show-Opcion '7' 'Revertir todos los cambios'
    Show-Opcion '0' 'Salir'
    Write-Host ''
    Write-Host ('  ' + ('-' * 64)) -ForegroundColor DarkYellow
    $op = Read-Host '   Seleccione una opcion'

    switch ($op) {
        '1' { Invoke-Modo -Reinicio { Invoke-OptimizacionCompleta } }
        '2' {
            Write-Host ''
            Write-Host '   Aplica los ajustes de Windows que mejoran el rendimiento: energia, efectos, servicios, disco y tareas.' -ForegroundColor Yellow
            if (Confirm-Accion '   Continuar?') { Invoke-Modo -Reinicio { Ejecutar '14-Optimizaciones-Windows.ps1' } }
        }
        '3' { Invoke-Modo { Ejecutar '15-Plan-Energia.ps1' } }
        '4' { Invoke-Modo { Ejecutar '13-Limpieza-Profunda.ps1' } }
        '5' { Invoke-Modo { Ejecutar '05-Reparacion.ps1' } }
        '6' { Invoke-Modo { Write-Log '=== PUNTO DE RESTAURACION ==='; New-PuntoRestauracion } }
        '7' {
            Write-Host ''
            Write-Host '   Se restauran: rendimiento, plan de energia, servicios, tareas, registro, memoria y programas de inicio.' -ForegroundColor Yellow
            Write-Host '   NO se restauran: archivos temporales borrados, Windows.old ni apps de la Tienda eliminadas.' -ForegroundColor Yellow
            if (Confirm-Accion '   Revertir los cambios?') { Invoke-Modo -Reinicio { Invoke-ReversionTotal } }
        }
        '0' { Write-Host ''; Write-Host '   Gracias por usar PC Optimizer.' -ForegroundColor Yellow; Write-Host ''; return }
        default { Write-Host '   Opcion no valida.' -ForegroundColor Yellow; Start-Sleep 1 }
    }
}
