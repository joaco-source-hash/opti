﻿# 02-Rendimiento.ps1 - Ajustes de rendimiento (reversibles con -Revertir)
param([switch]$Silencioso, [switch]$Revertir)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
$archivoBackup = 'backup_rendimiento.json'

if ($Revertir) {
    Write-Log '=== REVIRTIENDO AJUSTES DE RENDIMIENTO ==='
    Restore-RegistroDesdeBackup $archivoBackup
    Write-Log 'Listo. Cierre sesion y vuelva a entrar para ver todos los cambios.' 'OK'
    return
}

if (-not (Assert-Admin)) { return }
Write-Log '=== AJUSTES DE RENDIMIENTO ==='

# 1) Efectos visuales, Game DVR y apps en segundo plano (con backup)
$cambios = @(
    @{ Ruta = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize';             Nombre = 'EnableTransparency';   Valor = 0;   Tipo = 'DWord' },
    @{ Ruta = 'HKCU:\Control Panel\Desktop\WindowMetrics';                                      Nombre = 'MinAnimate';           Valor = '0'; Tipo = 'String' },
    @{ Ruta = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced';              Nombre = 'TaskbarAnimations';    Valor = 0;   Tipo = 'DWord' },
    @{ Ruta = 'HKCU:\System\GameConfigStore';                                                   Nombre = 'GameDVR_Enabled';      Valor = 0;   Tipo = 'DWord' },
    @{ Ruta = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR';                        Nombre = 'AppCaptureEnabled';    Valor = 0;   Tipo = 'DWord' },
    @{ Ruta = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications';   Nombre = 'GlobalUserDisabled';  Valor = 1;   Tipo = 'DWord' }
)
Set-RegistroConBackup -Cambios $cambios -ArchivoBackup $archivoBackup

# 2) Optimizar la unidad del sistema (TRIM en SSD, desfragmentar en HDD)
try {
    $letra = $env:SystemDrive.Substring(0, 1)
    $pd = Get-Partition -DriveLetter $letra -ErrorAction Stop | Get-Disk | Get-PhysicalDisk -ErrorAction Stop
    if ($pd.MediaType -eq 'SSD') {
        Optimize-Volume -DriveLetter $letra -ReTrim -ErrorAction Stop
        Write-Log 'SSD: TRIM ejecutado.' 'OK'
    } elseif ($pd.MediaType -eq 'HDD') {
        if ($Silencioso) {
            Write-Log 'HDD detectado: la desfragmentacion se omite en modo automatico (tarda mucho). Use la opcion Rendimiento del menu.' 'INFO'
        } elseif (Confirm-Accion 'Disco HDD: desfragmentar ahora? (puede tardar bastante)') {
            Optimize-Volume -DriveLetter $letra -Defrag -ErrorAction Stop
            Write-Log 'HDD desfragmentado.' 'OK'
        }
    } else {
        Write-Log 'Tipo de disco no identificado: optimizacion de unidad omitida.' 'INFO'
    }
} catch { Write-Log "Optimizacion de unidad omitida: $($_.Exception.Message)" 'WARN' }

# 3) Hibernacion (opcional: libera varios GB, pero quita el inicio rapido)
if (-not $Silencioso) {
    if (Confirm-Accion 'Desactivar hibernacion? (libera varios GB; se pierde Inicio rapido)') {
        powercfg /h off
        Write-Log 'Hibernacion desactivada.' 'OK'
    }
}

Write-Log 'Rendimiento listo. Algunos efectos visuales se ven al reiniciar sesion.' 'OK'
