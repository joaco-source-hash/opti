﻿# 12-Arranque-Rapido.ps1 - Acelera el inicio y el apagado de Windows
# Desactiva programas de inicio no esenciales, retrasa servicios pesados y acorta los tiempos de apagado.
# Reversible con -Revertir.
param([switch]$Revertir, [switch]$Silencioso)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
$bk = 'backup_arranque.json'
$bkSvc = 'backup_servicios_arranque.json'

if ($Revertir) {
    Write-Log '=== REVIRTIENDO ARRANQUE RAPIDO ==='
    if (Test-Path (Join-Path $global:OptDatosDir $bk)) { Restore-RegistroDesdeBackup $bk }
    Restore-ServiciosDesdeBackup -Archivo $bkSvc
    & (Join-Path $PSScriptRoot '03-Inicio.ps1') -Revertir
    return
}
if (-not (Assert-Admin)) { return }

Write-Log '=== ARRANQUE Y APAGADO RAPIDOS ==='
$bootAntes = Get-TiempoArranque
if ($null -ne $bootAntes) { Write-Log "Ultimo tiempo de arranque medido: $bootAntes s (compare despues de reiniciar)" 'INFO' }

# 1) Programas de inicio no esenciales
$n = Disable-InicioPorPatron $global:InicioSuave
Write-Log "Programas de inicio desactivados: $n" 'OK'

# 2) Servicios pesados pasan a inicio retrasado (arrancan despues de que el escritorio esta listo)
Set-ServiciosInicio @(
    @{ N = 'Spooler'; S = 5 }, @{ N = 'SysMain'; S = 5 }, @{ N = 'ClickToRunSvc'; S = 5 },
    @{ N = 'AdobeARMservice'; S = 5 }, @{ N = 'AdobeUpdateService'; S = 5 }
) -Archivo $bkSvc

# 3) Apagado mas rapido (tiempos de espera de servicios y aplicaciones)
$cambios = @(
    (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control' 'WaitToKillServiceTimeout' '3000' 'String'),
    (RegVal 'HKCU:\Control Panel\Desktop' 'WaitToKillAppTimeout' '3000' 'String'),
    (RegVal 'HKCU:\Control Panel\Desktop' 'HungAppTimeout' '2000' 'String')
)
Set-RegistroConBackup -Cambios $cambios -ArchivoBackup $bk -Resumen

# 4) Revision manual de lo que queda en el inicio
if (-not $Silencioso) {
    if (Confirm-Accion 'Revisar ahora los programas de inicio que quedan?') {
        & (Join-Path $PSScriptRoot '03-Inicio.ps1')
    }
}
Write-Log 'Arranque optimizado. Reinicie el equipo para ver el cambio.' 'OK'
