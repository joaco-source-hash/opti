﻿# 03-Inicio.ps1 - Administra los programas que arrancan con Windows (activar / desactivar)
param([switch]$Revertir)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
$archivoInicio = Join-Path $global:OptDatosDir 'backup_inicio.json'

if ($Revertir) {
    Write-Log '=== REVIRTIENDO PROGRAMAS DE INICIO ==='
    if (Test-Path $archivoInicio) {
        $guardados = Get-Content $archivoInicio -Raw -Encoding UTF8 | ConvertFrom-Json
        foreach ($g in @($guardados)) {
            try {
                Set-StartupState -Item $g -Habilitar ([bool]$g.HabilitadoOriginal)
                Write-Log "Inicio restaurado: $($g.Nombre)" 'OK'
            } catch { Write-Log "No se pudo restaurar $($g.Nombre)" 'WARN' }
        }
        Remove-Item $archivoInicio -Force -ErrorAction SilentlyContinue
    } else {
        Write-Log 'No hay cambios de inicio para revertir.' 'INFO'
    }
    return
}

$respaldo = @()
if (Test-Path $archivoInicio) {
    $previo = Get-Content $archivoInicio -Raw -Encoding UTF8 | ConvertFrom-Json
    $respaldo = @($previo)
}

Write-Log '=== PROGRAMAS DE INICIO ==='

while ($true) {
    $items = @(Get-StartupItems)
    Clear-Host
    Write-Host '=== PROGRAMAS QUE INICIAN CON WINDOWS ===' -ForegroundColor Cyan
    Write-Host 'No desactive antivirus ni controladores (audio, touchpad, video).' -ForegroundColor Yellow
    Write-Host ''
    if ($items.Count -eq 0) { Write-Host 'No se encontraron programas de inicio.'; break }

    for ($i = 0; $i -lt $items.Count; $i++) {
        $it = $items[$i]
        if ($it.Habilitado) { $estado = 'ACTIVO ';  $color = 'White' }
        else                { $estado = 'APAGADO'; $color = 'DarkGray' }
        Write-Host ("{0,2}. [{1}] {2}  ({3})" -f ($i + 1), $estado, $it.Nombre, $it.Origen) -ForegroundColor $color
    }
    Write-Host ''
    Write-Host 'Escriba los numeros a cambiar separados por coma (ej: 2,5). Enter para terminar.'
    $entrada = Read-Host 'Numeros'
    if ([string]::IsNullOrWhiteSpace($entrada)) { break }

    foreach ($n in ($entrada -split '[,\s]+' | Where-Object { $_ -match '^\d+$' })) {
        $idx = [int]$n - 1
        if ($idx -ge 0 -and $idx -lt $items.Count) {
            $it = $items[$idx]
            try {
                if (-not ($respaldo | Where-Object { $_.Nombre -eq $it.Nombre -and $_.Aprob -eq $it.Aprob })) {
                    $respaldo += [pscustomobject]@{ Nombre = $it.Nombre; Aprob = $it.Aprob; HabilitadoOriginal = [bool]$it.Habilitado }
                }
                Set-StartupState -Item $it -Habilitar (-not $it.Habilitado)
                ConvertTo-Json -InputObject @($respaldo) | Set-Content -Path $archivoInicio -Encoding UTF8
                $accion = if ($it.Habilitado) { 'desactivado' } else { 'activado' }
                Write-Log "$($it.Nombre): $accion" 'OK'
            } catch {
                Write-Log "No se pudo cambiar $($it.Nombre) (puede requerir Administrador): $($_.Exception.Message)" 'WARN'
            }
        }
    }
    Start-Sleep -Milliseconds 800
}
