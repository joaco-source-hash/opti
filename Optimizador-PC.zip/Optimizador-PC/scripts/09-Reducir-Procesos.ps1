﻿# 09-Reducir-Procesos.ps1 - Baja al maximo la cantidad de procesos y servicios en ejecucion
# Incluye los ajustes base (08), desactiva programas de inicio no esenciales, servicios innecesarios,
# widgets, Copilot, busqueda web y el segundo plano de los navegadores. Reversible con -Revertir.
param([switch]$Revertir)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
$bk = 'backup_procesos.json'
$bkSvc = 'backup_servicios_procesos.json'

if ($Revertir) {
    Write-Log '=== REVIRTIENDO REDUCCION DE PROCESOS ==='
    if (Test-Path (Join-Path $global:OptDatosDir $bk)) { Restore-RegistroDesdeBackup $bk }
    Restore-ServiciosDesdeBackup -Archivo $bkSvc
    & (Join-Path $PSScriptRoot '03-Inicio.ps1') -Revertir
    & (Join-Path $PSScriptRoot '08-Ajustes-Avanzados.ps1') -Revertir
    return
}
if (-not (Assert-Admin)) { return }

Write-Log '=== REDUCIR PROCESOS AL MAXIMO ==='
$procAntes = @(Get-Process).Count
$servAntes = @(Get-Service | Where-Object { $_.Status -eq 'Running' }).Count

# 1) Ajustes base: svchost agrupado, telemetria, servicios y tareas innecesarias
& (Join-Path $PSScriptRoot '08-Ajustes-Avanzados.ps1')

# 2) Programas de inicio no esenciales (OneDrive, Teams, Skype, Spotify, launchers, etc.)
$n = Disable-InicioPorPatron $global:InicioMaximo
Write-Log "Programas de inicio desactivados: $n" 'OK'

# 3) Widgets, chat, Copilot, busqueda web, segundo plano y navegadores
$cambios = @(
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Dsh' 'AllowNewsAndInterests' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Chat' 'ChatIcon' 3),
    (RegVal 'HKCU:\Software\Policies\Microsoft\Windows\WindowsCopilot' 'TurnOffWindowsCopilot' 1),
    (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'BingSearchEnabled' 0),
    (RegVal 'HKCU:\Software\Policies\Microsoft\Windows\Explorer' 'DisableSearchBoxSuggestions' 1),
    (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications' 'GlobalUserDisabled' 1),
    (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'TaskbarDa' 0),
    (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced' 'TaskbarMn' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'StartupBoostEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'BackgroundModeEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Google\Chrome' 'BackgroundModeEnabled' 0)
)
Set-RegistroConBackup -Cambios $cambios -ArchivoBackup $bk -Resumen

# 4) Servicios que no hacen falta en la mayoria de los equipos
$lista = @(
    @{ N = 'WSearch'; S = 4 }, @{ N = 'WMPNetworkSvc'; S = 4 }, @{ N = 'RetailDemo'; S = 4 },
    @{ N = 'wisvc'; S = 4 }, @{ N = 'PhoneSvc'; S = 4 }, @{ N = 'Fax'; S = 4 },
    @{ N = 'icssvc'; S = 4 }, @{ N = 'SEMgrSvc'; S = 4 }, @{ N = 'WalletService'; S = 4 },
    @{ N = 'WpcMonSvc'; S = 4 },
    @{ N = 'DoSvc'; S = 3; SoloAuto = $true }, @{ N = 'CDPSvc'; S = 3; SoloAuto = $true }
)
# SysMain (precarga) solo se apaga en SSD; en disco mecanico ayuda
if ((Get-TipoDisco) -eq 'SSD') { $lista += @{ N = 'SysMain'; S = 4 } }
Set-ServiciosInicio $lista -Archivo $bkSvc

$procDespues = @(Get-Process).Count
$servDespues = @(Get-Service | Where-Object { $_.Status -eq 'Running' }).Count
Write-Log "Procesos: $procAntes -> $procDespues | Servicios en ejecucion: $servAntes -> $servDespues" 'OK'
Write-Log 'REINICIE el equipo: la baja completa de procesos se ve despues de reiniciar.' 'OK'
