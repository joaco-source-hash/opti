﻿# 05-Reparacion.ps1 - Verifica y repara archivos del sistema y el disco
. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
if (-not (Assert-Admin)) { return }

Write-Log '=== REPARACION DEL SISTEMA ==='

# Estado de salud de los discos
try {
    Get-PhysicalDisk | ForEach-Object {
        $nivel = if ($_.HealthStatus -eq 'Healthy') { 'OK' } else { 'WARN' }
        Write-Log ("Disco {0} ({1}): {2}" -f $_.FriendlyName, $_.MediaType, $_.HealthStatus) $nivel
    }
} catch { Write-Log 'No se pudo leer el estado de los discos.' 'WARN' }

Write-Host ''
Write-Host 'Las siguientes tareas pueden tardar entre 10 y 40 minutos en total.' -ForegroundColor Yellow

if (Confirm-Accion 'Ejecutar DISM (reparar imagen de Windows)?') {
    Write-Log 'Ejecutando DISM...'
    DISM /Online /Cleanup-Image /RestoreHealth
    Write-Log "DISM finalizo con codigo $LASTEXITCODE" 'INFO'
}

if (Confirm-Accion 'Ejecutar SFC (verificar archivos del sistema)?') {
    Write-Log 'Ejecutando SFC...'
    sfc /scannow
    Write-Log "SFC finalizo con codigo $LASTEXITCODE" 'INFO'
}

if (Confirm-Accion 'Analizar el disco en busca de errores (sin reiniciar)?') {
    try {
        $letra = $env:SystemDrive.Substring(0, 1)
        $res = Repair-Volume -DriveLetter $letra -Scan
        Write-Log "Analisis de disco $letra`: $res" 'OK'
    } catch { Write-Log "No se pudo analizar el disco: $($_.Exception.Message)" 'WARN' }
}

Write-Log 'Reparacion finalizada. Se recomienda reiniciar el equipo.' 'OK'
