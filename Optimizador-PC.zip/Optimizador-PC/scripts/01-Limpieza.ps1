﻿# 01-Limpieza.ps1 - Limpia archivos temporales, caches y basura del sistema
# Parametros: -Simular (no borra, solo calcula)  -Silencioso (sin preguntas)  -IncluirPapelera
param([switch]$Simular, [switch]$Silencioso, [switch]$IncluirPapelera)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
if (-not (Assert-Admin)) { return }

Write-Log '=== LIMPIEZA DE ARCHIVOS ==='
if ($Simular) { Write-Log 'MODO SIMULACION: no se borra nada.' 'WARN' }
if (-not $Silencioso) {
    Write-Host 'Conviene cerrar los navegadores antes de continuar.' -ForegroundColor Yellow
    Read-Host 'Presione Enter para continuar' | Out-Null
}

$lista = @(
    @{ N = 'Temporales de usuario';        R = $env:TEMP },
    @{ N = 'Temporales de Windows';        R = "$env:SystemRoot\Temp" },
    @{ N = 'Volcados de errores';          R = "$env:LOCALAPPDATA\CrashDumps" },
    @{ N = 'Informes de errores (usuario)'; R = "$env:LOCALAPPDATA\Microsoft\Windows\WER" },
    @{ N = 'Informes de errores (equipo)'; R = "$env:ProgramData\Microsoft\Windows\WER\ReportQueue" },
    @{ N = 'Cache Delivery Optimization'; R = "$env:SystemRoot\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache" }
)

# Caches de navegadores basados en Chromium (NO toca contrasenas ni cookies)
$navegadores = @(
    @{ N = 'Chrome'; R = "$env:LOCALAPPDATA\Google\Chrome\User Data" },
    @{ N = 'Edge';   R = "$env:LOCALAPPDATA\Microsoft\Edge\User Data" },
    @{ N = 'Brave';  R = "$env:LOCALAPPDATA\BraveSoftware\Brave-Browser\User Data" }
)
foreach ($nav in $navegadores) {
    if (Test-Path $nav.R) {
        Get-ChildItem -Path $nav.R -Directory -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -eq 'Default' -or $_.Name -like 'Profile *' } |
            ForEach-Object {
                foreach ($sub in 'Cache\Cache_Data', 'Code Cache', 'GPUCache') {
                    $lista += @{ N = "Cache $($nav.N) ($($_.Name)) $sub"; R = (Join-Path $_.FullName $sub) }
                }
            }
    }
}
# Firefox
$ffRaiz = "$env:LOCALAPPDATA\Mozilla\Firefox\Profiles"
if (Test-Path $ffRaiz) {
    Get-ChildItem -Path $ffRaiz -Directory -ErrorAction SilentlyContinue | ForEach-Object {
        $lista += @{ N = "Cache Firefox ($($_.Name))"; R = (Join-Path $_.FullName 'cache2') }
    }
}

$totalMB = 0
foreach ($item in $lista) {
    $mb = Clear-Carpeta -Ruta $item.R -Simular:$Simular
    if ($mb -gt 0) {
        Write-Log ("{0}: {1} MB" -f $item.N, $mb) 'OK'
        $totalMB += $mb
    }
}

# Cache de Windows Update
$wu = "$env:SystemRoot\SoftwareDistribution\Download"
if (Test-Path $wu) {
    if ($Simular) {
        $mb = Clear-Carpeta -Ruta $wu -Simular
    } else {
        Stop-Service -Name wuauserv, bits -Force -ErrorAction SilentlyContinue
        try { $mb = Clear-Carpeta -Ruta $wu }
        finally { Start-Service -Name wuauserv, bits -ErrorAction SilentlyContinue }
    }
    if ($mb -gt 0) { Write-Log ("Cache de Windows Update: {0} MB" -f $mb) 'OK'; $totalMB += $mb }
}

# Logs y restos del sistema (solo archivos .log / .tmp / .bin)
$logs = @(
    @{ R = "$env:SystemRoot\Logs"; F = '*.log' },
    @{ R = "$env:SystemRoot\inf"; F = '*.log' },
    @{ R = "$env:SystemRoot\Panther"; F = '*.log' },
    @{ R = "$env:SystemRoot\Microsoft.NET"; F = '*.log' },
    @{ R = "$env:SystemRoot\SoftwareDistribution"; F = '*.log' },
    @{ R = "$env:LOCALAPPDATA\Microsoft\Windows\WebCache"; F = '*.log' },
    @{ R = "$env:LOCALAPPDATA\Microsoft\Windows\SettingSync"; F = '*.log' },
    @{ R = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer\ThumbCacheToDelete"; F = '*.tmp' },
    @{ R = "$env:LOCALAPPDATA\Microsoft\Terminal Server Client\Cache"; F = '*.bin' }
)
$mbLogs = 0
foreach ($l in $logs) {
    if (-not (Test-Path $l.R)) { continue }
    $archivos = @(Get-ChildItem -Path $l.R -Filter $l.F -Recurse -Force -File -ErrorAction SilentlyContinue)
    $bytes = ($archivos | Measure-Object -Property Length -Sum).Sum
    if (-not $Simular) { $archivos | Remove-Item -Force -ErrorAction SilentlyContinue }
    if ($bytes) { $mbLogs += [math]::Round($bytes / 1MB, 1) }
}
if ($mbLogs -gt 0) { Write-Log ("Logs y restos del sistema: {0} MB" -f $mbLogs) 'OK'; $totalMB += $mbLogs }

# Miniaturas
if (-not $Simular) {
    Get-ChildItem -Path "$env:LOCALAPPDATA\Microsoft\Windows\Explorer" -Filter 'thumbcache_*.db' -Force -ErrorAction SilentlyContinue |
        Remove-Item -Force -ErrorAction SilentlyContinue
}

# Cache DNS
if (-not $Simular) {
    Clear-DnsClientCache -ErrorAction SilentlyContinue
    Write-Log 'Cache DNS vaciada.' 'OK'
}

# Papelera (siempre con confirmacion, puede tener archivos que el cliente quiera)
$vaciar = $IncluirPapelera
if (-not $Silencioso -and -not $Simular) { $vaciar = Confirm-Accion 'Vaciar la Papelera de reciclaje?' }
if ($vaciar -and -not $Simular) {
    Clear-RecycleBin -Force -ErrorAction SilentlyContinue
    Write-Log 'Papelera vaciada.' 'OK'
}

$verbo = if ($Simular) { 'Se podrian liberar' } else { 'Total liberado' }
Write-Log ("{0}: {1} MB ({2} GB)" -f $verbo, $totalMB, [math]::Round($totalMB / 1024, 2)) 'OK'
