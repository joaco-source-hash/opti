﻿# 15-Plan-Energia.ps1 - Crea y activa el plan de energia "Maximo rendimiento"
# Usa: powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 (Maximo rendimiento de Windows)
# Reversible con -Revertir: vuelve al plan que estaba activo y elimina el plan creado.
param([switch]$Revertir, [switch]$Silencioso)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
$archivoPlan = Join-Path $global:OptDatosDir 'backup_plan_energia.txt'
$nombrePlan = 'Maximo rendimiento'
$patronGuid = '([0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12})'

function Get-PlanesCreados {
    # Planes de energia con el nombre de este programa (GUIDs)
    $res = @()
    foreach ($linea in @(powercfg /list)) {
        if ($linea -match "$patronGuid\s+\((.+?)\)" -and $Matches[3] -eq $nombrePlan) { $res += $Matches[1] }
    }
    return $res
}

if ($Revertir) {
    Write-Log '=== REVIRTIENDO PLAN DE ENERGIA ==='
    if (Test-Path $archivoPlan) {
        $guid = (Get-Content $archivoPlan -Encoding UTF8 | Select-Object -First 1)
        if ($guid) {
            powercfg /setactive $guid.Trim() 2>&1 | Out-Null
            if ($LASTEXITCODE -ne 0) { powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e | Out-Null }
            Write-Log 'Plan de energia original restaurado.' 'OK'
        }
        foreach ($g in @(Get-PlanesCreados)) { powercfg -delete $g | Out-Null }
        Remove-Item $archivoPlan -Force -ErrorAction SilentlyContinue
    }
    return
}
if (-not (Assert-Admin)) { return }

Write-Log '=== PLAN DE ENERGIA: MAXIMO RENDIMIENTO ==='

# En notebooks gasta mas bateria: se pregunta antes
if ([bool](Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue)) {
    if ($Silencioso) { Write-Log 'Notebook detectada: plan de energia sin cambios.' 'INFO'; return }
    if (-not (Confirm-Accion '   Es una notebook: el maximo rendimiento gasta mas bateria. Aplicarlo?')) { return }
}

try {
    # Guardar el plan actual para poder volver (una sola vez)
    $existentes = @(Get-PlanesCreados)
    $actual = powercfg /getactivescheme
    if ((-not (Test-Path $archivoPlan)) -and ($actual -match $patronGuid)) {
        if ($existentes -notcontains $Matches[1]) { Set-Content -Path $archivoPlan -Value $Matches[1] -Encoding UTF8 }
    }

    if ($existentes.Count -gt 0) {
        $guidPlan = $existentes[0]
    } else {
        $dup = powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61
        if (-not ($dup -match $patronGuid)) { throw 'Este equipo no permite crear el plan Maximo rendimiento.' }
        $guidPlan = $Matches[1]
        powercfg -changename $guidPlan $nombrePlan | Out-Null
    }
    powercfg /setactive $guidPlan | Out-Null
    Write-Log "Plan de energia '$nombrePlan' creado y activado." 'OK'
} catch {
    Write-Log "No se pudo crear el plan de energia: $($_.Exception.Message)" 'WARN'
}
