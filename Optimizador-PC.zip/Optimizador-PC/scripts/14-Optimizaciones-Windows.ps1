﻿# 14-Optimizaciones-Windows.ps1 - Conjunto de ajustes de Windows que realmente mejoran el rendimiento
# Combina: plan de energia y efectos (02), base del sistema (08), modo juegos (11) y los ajustes propios
# de este script (efectos visuales, velocidad del explorador, sistema de archivos, tareas pesadas).
# No incluye "trucos" sin efecto real ni cambios que bajen la seguridad. Reversible con -Revertir.
param([switch]$Revertir, [switch]$SinJuegos)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
$bk = 'backup_windows.json'
$bkTareas = 'backup_windows_tareas.json'
$archivoNtfs = Join-Path $global:OptDatosDir 'backup_windows_ntfs.txt'
$bkSvc = 'backup_windows_servicios.json'
$bagsBk = Join-Path $global:OptDatosDir 'backup_windows_bags.reg'
$bagMruBk = Join-Path $global:OptDatosDir 'backup_windows_bagmru.reg'
$archivoRecall = Join-Path $global:OptDatosDir 'backup_windows_recall.txt'
$shellRaiz = 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell'

if ($Revertir) {
    Write-Log '=== REVIRTIENDO OPTIMIZACIONES DE WINDOWS ==='
    if (Test-Path (Join-Path $global:OptDatosDir $bk)) { Restore-RegistroDesdeBackup $bk }
    Restore-TareasDesdeBackup -Archivo $bkTareas
    if (Test-Path $archivoNtfs) {
        $v = (Get-Content $archivoNtfs -Encoding UTF8 | Select-Object -First 1)
        if ($v -match '^\d$') {
            fsutil behavior set disablelastaccess $v | Out-Null
            Write-Log 'Sistema de archivos: actualizacion de ultimo acceso restaurada.' 'OK'
        }
        Remove-Item $archivoNtfs -Force -ErrorAction SilentlyContinue
    }
    Restore-ServiciosDesdeBackup -Archivo $bkSvc
    netsh interface teredo set state default | Out-Null
    if ((Test-Path $bagsBk) -or (Test-Path $bagMruBk)) {
        Remove-Item -Path "$shellRaiz\Bags" -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -Path "$shellRaiz\BagMRU" -Recurse -Force -ErrorAction SilentlyContinue
        foreach ($f in @($bagsBk, $bagMruBk)) {
            if (Test-Path $f) { reg import $f 2>&1 | Out-Null; Remove-Item $f -Force -ErrorAction SilentlyContinue }
        }
        Write-Log 'Vistas de carpetas restauradas (cierre sesion para verlas).' 'OK'
    }
    if (Test-Path $archivoRecall) {
        try { Enable-WindowsOptionalFeature -Online -FeatureName Recall -NoRestart -ErrorAction Stop | Out-Null; Write-Log 'Recall reactivado.' 'OK' }
        catch { Write-Log 'No se pudo reactivar Recall.' 'WARN' }
        Remove-Item $archivoRecall -Force -ErrorAction SilentlyContinue
    }
    & (Join-Path $PSScriptRoot '11-Modo-Juegos.ps1') -Revertir
    & (Join-Path $PSScriptRoot '08-Ajustes-Avanzados.ps1') -Revertir
    & (Join-Path $PSScriptRoot '02-Rendimiento.ps1') -Revertir
    return
}
if (-not (Assert-Admin)) { return }

Write-Log '=== OPTIMIZACIONES DE WINDOWS ==='

# 1) Plan de energia, efectos basicos, segundo plano, TRIM / desfragmentacion
& (Join-Path $PSScriptRoot '02-Rendimiento.ps1') -Silencioso

# 2) Base del sistema: telemetria, servicios y tareas innecesarias, svchost, prioridad multimedia y de red
& (Join-Path $PSScriptRoot '08-Ajustes-Avanzados.ps1')

# 3) Juegos y latencia: Modo Juego, GPU, prioridad de CPU, entrada, red (la opcion 1 lo ejecuta por separado)
if (-not $SinJuegos) { & (Join-Path $PSScriptRoot '11-Modo-Juegos.ps1') -Silencioso }

# 4) Ajustes propios
$adv = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
$cambios = @(
    # Las aplicaciones de inicio arrancan sin la espera artificial de Windows
    (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize' 'StartupDelayInMSec' 0),
    # Efectos visuales al minimo (se nota sobre todo en equipos con poca RAM o video integrado)
    (RegVal 'HKCU:\Control Panel\Desktop' 'DragFullWindows' '0' 'String'),
    (RegVal 'HKCU:\Control Panel\Desktop' 'UserPreferencesMask' ([byte[]](144, 18, 3, 128, 16, 0, 0, 0)) 'Binary'),
    (RegVal 'HKCU:\Control Panel\Keyboard' 'KeyboardDelay' '0' 'String'),
    (RegVal $adv 'ListviewAlphaSelect' 0),
    (RegVal $adv 'ListviewShadow' 0),
    (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 3),
    (RegVal 'HKCU:\Software\Microsoft\Windows\DWM' 'EnableAeroPeek' 0),
    (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'SearchboxTaskbarMode' 0),
    # Menos seguimiento de documentos recientes y sugerencias de busqueda
    (RegVal $adv 'Start_TrackDocs' 0),
    (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\SearchSettings' 'IsDynamicSearchBoxEnabled' 0),
    # Sin descargas/subidas entre equipos (Optimizacion de entrega solo por HTTP) y sin consultar datos de dispositivos en la red
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization' 'DODownloadMode' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Device Metadata' 'PreventDeviceMetadataFromNetwork' 1),
    # Impide que el firmware ejecute software del fabricante al iniciar (WPBT)
    (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' 'DisableWpbtExecution' 1),
    # Limpieza automatica de Storage Sense apagada (menos disco en segundo plano)
    (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy' '01' 0),
    # IPv4 con prioridad sobre IPv6 (evita demoras de conexion en redes con IPv6 mal configurado)
    (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters' 'DisabledComponents' 32),
    # IA de Windows: Recall y funciones de IA del Bloc de notas
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsAI' 'DisableAIDataAnalysis' 1),
    (RegVal 'HKLM:\SOFTWARE\Policies\WindowsNotepad' 'DisableAIFeatures' 1),
    # Edge sin recomendaciones, compras, rewards, widget ni envio de datos (menos actividad en segundo plano)
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\EdgeUpdate' 'CreateDesktopShortcutDefault' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'PersonalizationReportingEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'ShowRecommendationsEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'HideFirstRunExperience' 1),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'UserFeedbackAllowed' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'AlternateErrorPagesEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'EdgeCollectionsEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'EdgeShoppingAssistantEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'MicrosoftEdgeInsiderPromotionEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'ShowMicrosoftRewards' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'WebWidgetAllowed' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'DiagnosticData' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'EdgeAssetDeliveryServiceEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'WalletDonationEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'DefaultBrowserSettingsCampaignEnabled' 0),
    # Privacidad: voz en linea, personalizacion de escritura y recoleccion de contactos
    (RegVal 'HKCU:\Software\Microsoft\Speech_OneCore\Settings\OnlineSpeechPrivacy' 'HasAccepted' 0),
    (RegVal 'HKCU:\Software\Microsoft\InputPersonalization' 'RestrictImplicitInkCollection' 1),
    (RegVal 'HKCU:\Software\Microsoft\InputPersonalization' 'RestrictImplicitTextCollection' 1),
    (RegVal 'HKCU:\Software\Microsoft\InputPersonalization\TrainedDataStore' 'HarvestContacts' 0),
    (RegVal 'HKCU:\Software\Microsoft\Personalization\Settings' 'AcceptedPrivacyPolicy' 0),
    # Brave (si esta instalado): sin Rewards, Wallet, VPN, IA, noticias, Talk ni envio de metricas
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'BraveRewardsDisabled' 1),
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'BraveWalletDisabled' 1),
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'BraveVPNDisabled' 1),
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'BraveAIChatEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'BraveStatsPingEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'BraveNewsDisabled' 1),
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'BraveTalkDisabled' 1),
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'BraveP3AEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'UrlKeyedAnonymizedDataCollectionEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'SafeBrowsingExtendedReportingEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\BraveSoftware\Brave' 'MetricsReportingEnabled' 0)
)
Set-RegistroConBackup -Cambios $cambios -ArchivoBackup $bk -Resumen

# 5) Sistema de archivos: no escribir la fecha de ultimo acceso en cada lectura (menos escrituras al disco)
try {
    $salida = (fsutil behavior query disablelastaccess) -join ' '
    if ($salida -match '=\s*(\d)') {
        if (-not (Test-Path $archivoNtfs)) { Set-Content -Path $archivoNtfs -Value $Matches[1] -Encoding UTF8 }
        fsutil behavior set disablelastaccess 1 | Out-Null
        Write-Log 'Sistema de archivos: ultimo acceso desactivado.' 'OK'
    }
} catch { Write-Log "No se pudo ajustar el sistema de archivos: $($_.Exception.Message)" 'WARN' }

# 6) Tareas programadas que consumen CPU o disco en segundo plano
Disable-TareasProgramadas -Archivo $bkTareas -Tareas @(
    '\Microsoft\Windows\Maintenance\WinSAT',
    '\Microsoft\Windows\Power Efficiency Diagnostics\AnalyzeSystem',
    '\Microsoft\Windows\Shell\FamilySafetyMonitor',
    '\Microsoft\Windows\Shell\FamilySafetyRefreshTask',
    '\Microsoft\Windows\NetTrace\GatherNetworkInfo',
    '\Microsoft\Windows\Mobile Broadband Accounts\MNO Metadata Parser',
    '\Microsoft\Windows\Windows Media Sharing\UpdateLibrary'
)

# 7) Servicios de IA de Windows y de administracion Intel (no necesarios en equipos de uso normal)
Set-ServiciosInicio @(@{ N = 'WSAIFabricSvc'; S = 4 }, @{ N = 'LMS'; S = 4 }) -Archivo $bkSvc

# 8) Teredo (tunel IPv6 sobre IPv4) apagado: menos trafico y conexiones de fondo
netsh interface teredo set state disabled | Out-Null
Write-Log 'Teredo desactivado.' 'OK'

# 9) Recall (funcion de IA de Windows 11 24H2 o superior), si esta instalada
try {
    $rec = Get-WindowsOptionalFeature -Online -FeatureName Recall -ErrorAction Stop
    if ($rec.State -eq 'Enabled') {
        Set-Content -Path $archivoRecall -Value 'Enabled' -Encoding UTF8
        Disable-WindowsOptionalFeature -Online -FeatureName Recall -NoRestart -ErrorAction Stop | Out-Null
        Write-Log 'Recall desactivado.' 'OK'
    }
} catch { }

# 10) Deteccion automatica del tipo de carpeta: Explorer deja de analizar el contenido de cada carpeta
#     (abre carpetas mas rapido). Se guarda una copia de las vistas actuales para poder revertir.
try {
    if (-not ((Test-Path $bagsBk) -or (Test-Path $bagMruBk))) {
        reg export 'HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags' $bagsBk /y 2>&1 | Out-Null
        reg export 'HKCU\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU' $bagMruBk /y 2>&1 | Out-Null
    }
    Remove-Item -Path "$shellRaiz\Bags" -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -Path "$shellRaiz\BagMRU" -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -Path "$shellRaiz\Bags\AllFolders\Shell" -Force | Out-Null
    Set-ItemProperty -Path "$shellRaiz\Bags\AllFolders\Shell" -Name 'FolderType' -Value 'NotSpecified' -Type String
    Write-Log 'Explorer: deteccion automatica de carpetas desactivada (cierre sesion para verlo).' 'OK'
} catch { Write-Log "No se pudo ajustar las vistas de carpetas: $($_.Exception.Message)" 'WARN' }

Write-Log 'Optimizaciones de Windows aplicadas. REINICIE el equipo para que todas queden activas.' 'OK'
