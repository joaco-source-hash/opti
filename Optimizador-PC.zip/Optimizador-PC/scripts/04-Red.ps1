﻿# 04-Red.ps1 - Optimizacion y diagnostico de red
param([switch]$Silencioso)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
if (-not (Assert-Admin)) { return }

Write-Log '=== OPTIMIZACION DE RED ==='

$antes = Get-Latencia
if ($null -ne $antes) { Write-Log "Latencia inicial a 8.8.8.8: $antes ms" 'INFO' }
else { Write-Log 'No hay respuesta de Internet en la prueba inicial.' 'WARN' }

Clear-DnsClientCache -ErrorAction SilentlyContinue
Write-Log 'Cache DNS vaciada.' 'OK'

if (-not $Silencioso) {
    Write-Host ''
    Write-Host 'Servidores DNS para los adaptadores activos:'
    Write-Host '  1) Cloudflare (1.1.1.1 / 1.0.0.1)'
    Write-Host '  2) Google     (8.8.8.8 / 8.8.4.4)'
    Write-Host '  3) Automatico (restaurar el valor del router/ISP)'
    Write-Host '  0) No cambiar'
    $op = Read-Host 'Opcion'
    $dns = switch ($op) {
        '1' { @('1.1.1.1', '1.0.0.1') }
        '2' { @('8.8.8.8', '8.8.4.4') }
        default { $null }
    }
    if ($op -in '1', '2', '3') {
        $adaptadores = Get-NetAdapter -Physical -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Up' }
        foreach ($a in $adaptadores) {
            try {
                if ($op -eq '3') { Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ResetServerAddresses -ErrorAction Stop }
                else             { Set-DnsClientServerAddress -InterfaceIndex $a.ifIndex -ServerAddresses $dns -ErrorAction Stop }
                Write-Log "DNS actualizado en: $($a.Name)" 'OK'
            } catch { Write-Log "No se pudo cambiar DNS en $($a.Name): $($_.Exception.Message)" 'WARN' }
        }
    }

    if (Confirm-Accion 'Reiniciar pila de red (Winsock/IP)? Requiere reiniciar el equipo') {
        netsh winsock reset | Out-Null
        netsh int ip reset | Out-Null
        Write-Log 'Pila de red reiniciada. Reinicie el equipo.' 'OK'
    }
}

$despues = Get-Latencia
if ($null -ne $despues) { Write-Log "Latencia final a 8.8.8.8: $despues ms" 'OK' }
