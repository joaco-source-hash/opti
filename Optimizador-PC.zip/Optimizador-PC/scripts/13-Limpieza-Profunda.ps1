﻿# 13-Limpieza-Profunda.ps1 - Limpieza completa del disco (mas a fondo que la limpieza normal)
# Incluye: limpieza normal, caches de aplicaciones, restos de Windows y de actualizaciones, componentes de Windows
# y un listado de los archivos mas grandes del perfil (solo lectura).
param([switch]$Silencioso)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
if (-not (Assert-Admin)) { return }

Write-Log '=== LIMPIEZA PROFUNDA ==='
Write-Host 'Cierre los navegadores y aplicaciones antes de continuar.' -ForegroundColor Yellow
if (-not $Silencioso) { Read-Host 'Presione Enter para continuar' | Out-Null }

$libreAntes = (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($env:SystemDrive)'").FreeSpace

# 1) Limpieza normal (temporales, navegadores, Windows Update, logs, DNS)
& (Join-Path $PSScriptRoot '01-Limpieza.ps1') -Silencioso

# 2) Caches de aplicaciones comunes (se regeneran solas)
$caches = @(
    "$env:APPDATA\discord\Cache", "$env:APPDATA\discord\Code Cache", "$env:APPDATA\discord\GPUCache",
    "$env:APPDATA\Microsoft\Teams\Cache", "$env:APPDATA\Microsoft\Teams\Code Cache", "$env:APPDATA\Microsoft\Teams\GPUCache",
    "$env:LOCALAPPDATA\Steam\htmlcache", "$env:LOCALAPPDATA\Microsoft\Windows\INetCache"
)
$mbApps = 0
foreach ($c in $caches) { $mbApps += Clear-Carpeta -Ruta $c }
if ($mbApps -gt 0) { Write-Log "Caches de aplicaciones: $mbApps MB" 'OK' }

# 3) Restos de Windows y de actualizaciones (limpieza directa, sin el Liberador de espacio que se cuelga en algunos equipos)
$restos = @(
    @{ N = 'Volcados de memoria';                R = "$env:SystemRoot\Minidump" },
    @{ N = 'Programas descargados';              R = "$env:SystemRoot\Downloaded Program Files" },
    @{ N = 'Registros de instalacion (CBS)';     R = "$env:SystemRoot\Logs\CBS" },
    @{ N = 'Registros de Windows Update';        R = "$env:SystemRoot\Logs\WindowsUpdate" },
    @{ N = 'Informes de errores archivados';     R = "$env:ProgramData\Microsoft\Windows\WER\ReportArchive" },
    @{ N = 'Optimizacion de entrega (cache)';    R = "$env:ProgramData\Microsoft\Windows\DeliveryOptimization\Cache" }
)
foreach ($r in $restos) {
    $mb = Clear-Carpeta -Ruta $r.R
    if ($mb -gt 0) { Write-Log ("{0}: {1} MB" -f $r.N, $mb) 'OK' }
}
if (Test-Path "$env:SystemRoot\MEMORY.DMP") {
    Remove-Item "$env:SystemRoot\MEMORY.DMP" -Force -ErrorAction SilentlyContinue
    Write-Log 'Volcado de memoria completo eliminado.' 'OK'
}

# Windows.old solo con confirmacion: impide volver a la version anterior de Windows
$wo = "$env:SystemDrive\Windows.old"
if ((Test-Path $wo) -and -not $Silencioso) {
    if (Confirm-Accion 'Se encontro Windows.old (version anterior de Windows). Eliminarla? No se puede deshacer') {
        Write-Log 'Eliminando Windows.old (puede tardar varios minutos)...'
        # takeown pide la respuesta "si" segun el idioma de Windows
        $si = switch ((Get-Culture).TwoLetterISOLanguageName) { 'es' { 'S' } 'pt' { 'S' } 'it' { 'S' } 'fr' { 'O' } 'de' { 'J' } default { 'Y' } }
        takeown /f $wo /r /d $si 2>&1 | Out-Null
        icacls $wo /grant '*S-1-5-32-544:F' /t /c /q 2>&1 | Out-Null
        Remove-Item -Path $wo -Recurse -Force -ErrorAction SilentlyContinue
        if (Test-Path $wo) { cmd /c rd /s /q "$wo" 2>&1 | Out-Null }
        if (Test-Path $wo) { Write-Log 'No se pudo eliminar Windows.old por completo.' 'WARN' } else { Write-Log 'Windows.old eliminada.' 'OK' }
    }
}

# 4) Componentes de Windows (WinSxS), sin eliminar la posibilidad de desinstalar actualizaciones
Write-Log 'Limpiando componentes de Windows (puede tardar)...'
DISM /Online /Cleanup-Image /StartComponentCleanup
Write-Log "DISM finalizo con codigo $LASTEXITCODE" 'INFO'

# 5) Archivos grandes (solo informa, no borra nada)
if (-not $Silencioso) {
    Write-Log 'Buscando archivos de mas de 500 MB en su perfil (solo lectura)...'
    $grandes = Get-ChildItem -Path $env:USERPROFILE -Recurse -File -Force -ErrorAction SilentlyContinue |
        Where-Object { $_.Length -gt 500MB } | Sort-Object Length -Descending | Select-Object -First 10
    if ($grandes) {
        foreach ($g in $grandes) { Write-Log ("{0,7:N1} GB  {1}" -f ($g.Length / 1GB), $g.FullName) 'INFO' }
    } else { Write-Log 'No hay archivos grandes en el perfil.' 'INFO' }
}

$libreDespues = (Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$($env:SystemDrive)'").FreeSpace
$liberado = [math]::Round(($libreDespues - $libreAntes) / 1GB, 2)
Write-Log "Espacio liberado en $($env:SystemDrive): $liberado GB" 'OK'
