﻿# 08-Ajustes-Avanzados.ps1 - Reduce servicios, tareas y procesos innecesarios de Windows
# Siempre aplica los ajustes base (telemetria, servicios, tareas, svchost).
# Siempre aplica tambien: efectos visuales, navegadores en segundo plano y ajustes segun disco/RAM.
# Con -Avanzado agrega ademas la eliminacion de apps preinstaladas de la Tienda.
# Registro, servicios y tareas son reversibles con -Revertir. Las apps eliminadas no.
param([switch]$Avanzado, [switch]$Revertir)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
if (-not (Assert-Admin)) { return }

$bkEsencial  = 'backup_ajustes_esencial.json'
$bkVisual    = 'backup_ajustes_visual.json'
$bkNavegador = 'backup_ajustes_navegadores.json'
$bkTareas    = Join-Path $global:OptDatosDir 'backup_ajustes_tareas.json'
$bkExtras    = 'backup_ajustes_extras.json'
$bkMemoria   = Join-Path $global:OptDatosDir 'backup_ajustes_memoria.txt'

# =====================================================================
#  REVERTIR
# =====================================================================
if ($Revertir) {
    Write-Log '=== REVIRTIENDO AJUSTES AVANZADOS ==='
    # Orden inverso al de aplicacion
    foreach ($b in @($bkExtras, $bkNavegador, $bkVisual, $bkEsencial)) {
        if (Test-Path (Join-Path $global:OptDatosDir $b)) { Restore-RegistroDesdeBackup $b }
    }
    Restore-ServiciosDesdeBackup
    Restore-TareasDesdeBackup
    Restore-MemoriaDesdeBackup
    Write-Log 'Ajustes revertidos. Reinicie el equipo. (Las apps de la Tienda eliminadas se reinstalan desde Microsoft Store.)' 'OK'
    return
}

Write-Log '=== AJUSTES AVANZADOS DEL SISTEMA ==='

$ramGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB, 1)

# =====================================================================
#  PARTE A - ESENCIALES
# =====================================================================
$aplicarA = $true

if ($aplicarA) {
    # ---- A1) Registro ----
    $ramKB = [int][math]::Min([math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1KB), 2147483647)
    $cdm = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'
    $adv = 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
    $sysProfile = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'

    $cambios = @(
        # Actividad
        (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' 'EnableActivityFeed' 0),
        (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' 'PublishUserActivities' 0),
        (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' 'UploadUserActivities' 0),
        # Ubicacion
        (RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\location' 'Value' 'Deny' 'String'),
        (RegVal 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Sensor\Overrides\{BFA794E4-F964-4FDB-90F6-51056BFE4B44}' 'SensorPermissionState' 0),
        (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc\Service\Configuration' 'Status' 0),
        (RegVal 'HKLM:\SYSTEM\Maps' 'AutoUpdateEnabled' 0),
        # Wifi-Sense
        (RegVal 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowWiFiHotSpotReporting' 'Value' 0),
        (RegVal 'HKLM:\SOFTWARE\Microsoft\PolicyManager\default\WiFi\AllowAutoConnectToWiFiSenseHotspots' 'Value' 0),
        # Terminar tarea con clic derecho en la barra
        (RegVal "$adv\TaskbarDeveloperSettings" 'TaskbarEndTask' 1),
        # Telemetria
        (RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection' 'AllowTelemetry' 0),
        (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' 'AllowTelemetry' 0),
        (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' 'DoNotShowFeedbackNotifications' 1),
        (RegVal $cdm 'ContentDeliveryAllowed' 0),
        (RegVal $cdm 'OemPreInstalledAppsEnabled' 0),
        (RegVal $cdm 'PreInstalledAppsEnabled' 0),
        (RegVal $cdm 'PreInstalledAppsEverEnabled' 0),
        (RegVal $cdm 'SilentInstalledAppsEnabled' 0),
        (RegVal $cdm 'SystemPaneSuggestionsEnabled' 0),
        (RegVal $cdm 'SubscribedContent-338387Enabled' 0),
        (RegVal $cdm 'SubscribedContent-338388Enabled' 0),
        (RegVal $cdm 'SubscribedContent-338389Enabled' 0),
        (RegVal $cdm 'SubscribedContent-353698Enabled' 0),
        (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' 'Enabled' 0),
        (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy' 'TailoredExperiencesWithDiagnosticDataEnabled' 0),
        (RegVal 'HKCU:\Control Panel\International\User Profile' 'HttpAcceptLanguageOptOut' 1),
        (RegVal $adv 'Start_TrackProgs' 0),
        (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' 'DisableWindowsConsumerFeatures' 1),
        (RegVal 'HKCU:\SOFTWARE\Microsoft\Siuf\Rules' 'NumberOfSIUFInPeriod' 0),
        (RegVal 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\CloudContent' 'DisableTailoredExperiencesWithDiagnosticData' 1),
        (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo' 'DisabledByGroupPolicy' 1),
        (RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\Windows Error Reporting' 'Disabled' 1),
        (RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DeliveryOptimization\Config' 'DODownloadMode' 1),
        (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' 'fAllowToGetHelp' 0),
        (RegVal 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\OperationStatusManager' 'EnthusiastMode' 1),
        (RegVal $adv 'ShowTaskViewButton' 0),
        (RegVal $adv 'LaunchTo' 1),
        (RegVal "$adv\People" 'PeopleBand' 0),
        (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem' 'LongPathsEnabled' 1),
        (RegVal $sysProfile 'SystemResponsiveness' 0),
        (RegVal $sysProfile 'NetworkThrottlingIndex' (-1)),
        (RegVal 'HKCU:\Control Panel\Desktop' 'MenuShowDelay' '1' 'String'),
        (RegVal 'HKCU:\Control Panel\Mouse' 'MouseHoverTime' '400' 'String'),
        # Cierra solo las aplicaciones colgadas al apagar o cerrar sesion
        (RegVal 'HKCU:\Control Panel\Desktop' 'AutoEndTasks' '1' 'String'),
        # Busqueda de controladores: Windows Update primero
        (RegVal 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\DriverSearching' 'SearchOrderConfig' 1),
        (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters' 'IRPStackSize' 30),
        (RegVal 'HKCU:\SOFTWARE\Policies\Microsoft\Windows\Windows Feeds' 'EnableFeeds' 0),
        (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Feeds' 'ShellFeedsTaskbarViewMode' 2),
        (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer' 'HideSCAMeetNow' 1),
        (RegVal "$sysProfile\Tasks\Games" 'GPU Priority' 8),
        (RegVal "$sysProfile\Tasks\Games" 'Priority' 6),
        (RegVal "$sysProfile\Tasks\Games" 'Scheduling Category' 'High' 'String'),
        (RegVal "$sysProfile\Tasks\Games" 'Affinity' 0),
        (RegVal "$sysProfile\Tasks\Games" 'Background Only' 'False' 'String'),
        (RegVal "$sysProfile\Tasks\Games" 'Clock Rate' 10000),
        (RegVal "$sysProfile\Tasks\Games" 'SFIO Priority' 'High' 'String'),
        (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' 'MaxCmds' 100),
        (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' 'MaxThreads' 100),
        (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters' 'MaxCollectionCount' 32),
        (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\AppCompat' 'AITEnable' 0),
        (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\UserProfileEngagement' 'ScoobeSystemSettingEnabled' 0),
        # Agrupa servicios en menos procesos svchost.exe (efecto completo tras reiniciar)
        (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control' 'SvcHostSplitThresholdInKB' $ramKB)
    )
    Write-Log 'Aplicando ajustes de registro (telemetria, actividad, ubicacion, svchost...)'
    Set-RegistroConBackup -Cambios $cambios -ArchivoBackup $bkEsencial

    # ---- A2) Servicios (4 = deshabilitado, 3 = manual) ----
    # SharedAccess (uso compartido de Internet / zona Wi-Fi) se deja en Manual en lugar de Deshabilitado.
    $servicios = @(
        @{ N = 'DiagTrack'; S = 4 }, @{ N = 'CscService'; S = 4 }, @{ N = 'RemoteAccess'; S = 4 },
        @{ N = 'RemoteRegistry'; S = 4 }, @{ N = 'ssh-agent'; S = 4 }, @{ N = 'AJRouter'; S = 4 },
        @{ N = 'AppVClient'; S = 4 }, @{ N = 'AssignedAccessManagerSvc'; S = 4 }, @{ N = 'DialogBlockingService'; S = 4 },
        @{ N = 'NetTcpPortSharing'; S = 4 }, @{ N = 'UevAgentService'; S = 4 }, @{ N = 'shpamsvc'; S = 4 },
        @{ N = 'tzautoupdate'; S = 4 }, @{ N = 'uhssvc'; S = 4 }, @{ N = 'SystemUsageReportSvc_QUEENCREEK'; S = 4 },
        @{ N = 'GpuEnergyDrv'; S = 4 }, @{ N = 'TrkWks'; S = 4 }, @{ N = 'WerSvc'; S = 4 },
        @{ N = 'Wecsvc'; S = 4 }, @{ N = 'GraphicsPerfSvc'; S = 4 }, @{ N = 'PcaSvc'; S = 4 },
        @{ N = 'dmwappushservice'; S = 4 }, @{ N = 'diagsvc'; S = 4 }, @{ N = 'diagnosticshub.standardcollector.service'; S = 4 },
        @{ N = 'MapsBroker'; S = 3 }, @{ N = 'StorSvc'; S = 3 }, @{ N = 'SharedAccess'; S = 3 },
        @{ N = 'TermService'; S = 3 }, @{ N = 'TroubleshootingSvc'; S = 3 }, @{ N = 'seclogon'; S = 3 },
        @{ N = 'HomeGroupListener'; S = 3 }, @{ N = 'HomeGroupProvider'; S = 3 }
    )
    Set-ServiciosInicio $servicios

    # Servicios que hoy arrancan en Automatico y pasan a Manual (solo esos; la seguridad,
    # las actualizaciones, las copias de respaldo y los servicios basicos quedan excluidos).
    $paraManual = @(
    'AJRouter', 'ALG', 'AppIDSvc', 'AppMgmt', 'AppReadiness', 'AssignedAccessManagerSvc',
    'AxInstSV', 'BDESVC', 'BTAGService', 'Browser', 'CertPropSvc', 'CscService',
    'DcpSvc', 'DevQueryBroker', 'DeviceAssociationService', 'DeviceInstall', 'DisplayEnhancementService', 'DmEnrollmentSvc',
    'DsSvc', 'DsmSvc', 'EapHost', 'EntAppSvc', 'FDResPub', 'Fax',
    'FrameServer', 'FrameServerMonitor', 'GraphicsPerfSvc', 'HomeGroupListener', 'HomeGroupProvider', 'HvHost',
    'IEEtwCollectorService', 'IKEEXT', 'InstallService', 'InventorySvc', 'IpxlatCfgSvc', 'KtmRm',
    'LxpSvc', 'MSDTC', 'MSiSCSI', 'McpManagementService', 'MicrosoftEdgeElevationService', 'MixedRealityOpenXRSvc',
    'NaturalAuthentication', 'NcaSvc', 'NcbService', 'NcdAutoSetup', 'NetSetupSvc', 'PNRPAutoReg',
    'PNRPsvc', 'PeerDistSvc', 'PerfHost', 'PhoneSvc', 'PolicyAgent', 'PrintNotify',
    'PushToInstall', 'QWAVE', 'RasAuto', 'RasMan', 'RetailDemo', 'RmSvc',
    'RpcLocator', 'SCPolicySvc', 'SCardSvr', 'SDRSVC', 'SEMgrSvc', 'SNMPTRAP',
    'SNMPTrap', 'SSDPSRV', 'ScDeviceEnum', 'SensorDataService', 'SensorService', 'SensrSvc',
    'SessionEnv', 'SharedAccess', 'SharedRealitySvc', 'SmsRouter', 'SstpSvc', 'StiSvc',
    'TapiSrv', 'TieringEngineService', 'TroubleshootingSvc', 'UI0Detect', 'UmRdpService', 'VacSvc',
    'WEPHOSTSVC', 'WFDSConMgrSvc', 'WMPNetworkSvc', 'WManSvc', 'WPDBusEnum', 'WSService',
    'WalletService', 'WarpJITSvc', 'WcsPlugInService', 'WdiServiceHost', 'WdiSystemHost', 'WebClient',
    'Wecsvc', 'WerSvc', 'WiaRpc', 'WinHttpAutoProxySvc', 'WinRM', 'WpcMonSvc',
    'XblAuthManager', 'XblGameSave', 'XboxGipSvc', 'XboxNetApiSvc', 'autotimesvc', 'bthserv',
    'camsvc', 'cloudidsvc', 'dcsvc', 'defragsvc', 'diagnosticshub.standardcollector.service', 'diagsvc',
    'dmwappushservice', 'dot3svc', 'edgeupdate', 'edgeupdatem', 'embeddedmode', 'fdPHost',
    'fhsvc', 'icssvc', 'lfsvc', 'lltdsvc', 'msiserver', 'p2pimsvc',
    'p2psvc', 'perceptionsimulation', 'pla', 'seclogon', 'smphost', 'spectrum',
    'svsvc', 'upnphost', 'vmicguestinterface', 'vmicheartbeat', 'vmickvpexchange', 'vmicrdv',
    'vmicshutdown', 'vmictimesync', 'vmicvmsession', 'vmicvss', 'vmvss', 'wcncsvc',
    'wercplsupport', 'wisvc', 'wlidsvc', 'wlpasvc', 'wmiApSrv', 'workfolderssvc',
    'wudfsvc', 'TabletInputService', 'lmhosts'
    )
    Set-ServiciosInicio @($paraManual | ForEach-Object { @{ N = $_; S = 3; SoloAuto = $true } })

    # ---- A3) Tareas programadas de telemetria ----
    $tareas = @(
        '\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser',
        '\Microsoft\Windows\Application Experience\ProgramDataUpdater',
        '\Microsoft\Windows\Application Experience\MareBackup',
        '\Microsoft\Windows\Application Experience\StartupAppTask',
        '\Microsoft\Windows\Application Experience\PcaPatchDbTask',
        '\Microsoft\Windows\Autochk\Proxy',
        '\Microsoft\Windows\Customer Experience Improvement Program\Consolidator',
        '\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip',
        '\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector',
        '\Microsoft\Windows\Feedback\Siuf\DmClient',
        '\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload',
        '\Microsoft\Windows\Windows Error Reporting\QueueReporting',
        '\Microsoft\Windows\Maps\MapsUpdateTask'
    )
    $bkTar = @()
    foreach ($t in $tareas) {
        $i = $t.LastIndexOf('\')
        $ruta = $t.Substring(0, $i + 1)
        $nombre = $t.Substring($i + 1)
        $obj = Get-ScheduledTask -TaskPath $ruta -TaskName $nombre -ErrorAction SilentlyContinue
        if ($obj -and $obj.State -ne 'Disabled') {
            try {
                Disable-ScheduledTask -TaskPath $ruta -TaskName $nombre -ErrorAction Stop | Out-Null
                $bkTar += [pscustomobject]@{ Ruta = $ruta; Nombre = $nombre }
                Write-Log "Tarea desactivada: $nombre" 'OK'
            } catch { Write-Log "No se pudo desactivar la tarea $nombre" 'WARN' }
        }
    }
    if ($bkTar.Count -gt 0 -and -not (Test-Path $bkTareas)) {
        ConvertTo-Json -InputObject $bkTar | Set-Content -Path $bkTareas -Encoding UTF8
    }

    # ---- A4) Rastro de telemetria en disco ----
    Remove-Item "$env:ProgramData\Microsoft\Diagnosis\ETLLogs\AutoLogger\AutoLogger-Diagtrack-Listener.etl" -Force -ErrorAction SilentlyContinue
    Write-Log 'Ajustes base aplicados.' 'OK'
}

# =====================================================================
#  PARTE B - VISUAL, NAVEGADORES, APPS (solo con -Avanzado) Y AJUSTES SEGUN EL EQUIPO
# =====================================================================
# ---- B1) Efectos visuales al minimo ----
if ($true) {
    $cambiosVisual = @(
        (RegVal 'HKCU:\Control Panel\Desktop' 'DragFullWindows' '0' 'String'),
        (RegVal 'HKCU:\Control Panel\Desktop' 'MenuShowDelay' '200' 'String'),
        (RegVal 'HKCU:\Control Panel\Desktop' 'UserPreferencesMask' ([byte[]](144, 18, 3, 128, 16, 0, 0, 0)) 'Binary'),
        (RegVal 'HKCU:\Control Panel\Desktop\WindowMetrics' 'MinAnimate' '0' 'String'),
        (RegVal 'HKCU:\Control Panel\Keyboard' 'KeyboardDelay' '0' 'String'),
        (RegVal "$adv" 'ListviewAlphaSelect' 0),
        (RegVal "$adv" 'ListviewShadow' 0),
        (RegVal "$adv" 'TaskbarAnimations' 0),
        (RegVal "$adv" 'TaskbarMn' 0),
        (RegVal "$adv" 'TaskbarDa' 0),
        (RegVal "$adv" 'ShowTaskViewButton' 0),
        (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects' 'VisualFXSetting' 3),
        (RegVal 'HKCU:\Software\Microsoft\Windows\DWM' 'EnableAeroPeek' 0),
        (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Search' 'SearchboxTaskbarMode' 0)
    )
    Set-RegistroConBackup -Cambios $cambiosVisual -ArchivoBackup $bkVisual
    Write-Log 'Efectos visuales ajustados. Cierre sesion para verlos completos.' 'OK'
}

# ---- B2) Menos procesos de navegadores en segundo plano ----
if ($true) {
    $cambiosNav = @(
        (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'StartupBoostEnabled' 0),
        (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'BackgroundModeEnabled' 0),
        (RegVal 'HKLM:\SOFTWARE\Policies\Google\Chrome' 'BackgroundModeEnabled' 0)
    )
    Set-RegistroConBackup -Cambios $cambiosNav -ArchivoBackup $bkNavegador
}

# ---- B3) Apps preinstaladas de la Tienda (NO reversible desde este kit) ----
$appsGenerales = @(
    'Microsoft.Microsoft3DViewer', 'Microsoft.AppConnector', 'Microsoft.BingFinance', 'Microsoft.BingNews',
    'Microsoft.BingSports', 'Microsoft.BingTranslator', 'Microsoft.BingWeather', 'Microsoft.BingFoodAndDrink',
    'Microsoft.BingHealthAndFitness', 'Microsoft.BingTravel', 'Microsoft.GetHelp', 'Microsoft.Getstarted',
    'Microsoft.Messaging', 'Microsoft.MicrosoftSolitaireCollection', 'Microsoft.NetworkSpeedTest', 'Microsoft.News',
    'Microsoft.Office.Lens', 'Microsoft.Office.Sway', 'Microsoft.Office.OneNote', 'Microsoft.OneConnect',
    'Microsoft.People', 'Microsoft.Print3D', 'Microsoft.SkypeApp', 'Microsoft.Wallet', 'Microsoft.Whiteboard',
    'Microsoft.WindowsAlarms', 'Microsoft.WindowsFeedbackHub', 'Microsoft.WindowsMaps', 'Microsoft.WindowsPhone',
    'Microsoft.WindowsSoundRecorder', 'Microsoft.ConnectivityStore', 'Microsoft.CommsPhone',
    'Microsoft.ZuneMusic', 'Microsoft.ZuneVideo', 'Microsoft.MicrosoftOfficeHub',
    '*EclipseManager*', '*ActiproSoftwareLLC*', '*AdobePhotoshopExpress*', '*Duolingo*', '*PandoraMediaInc*',
    '*CandyCrush*', '*BubbleWitch3Saga*', '*Wunderlist*', '*Flipboard*', '*Twitter*', '*Facebook*',
    '*Royal Revolt*', '*Sway*', '*Speed Test*', '*Viber*', '*ACGMediaPlayer*', '*Netflix*', '*OneCalendar*',
    '*LinkedInforWindows*', '*HiddenCity*', '*Hulu*', '*HotspotShieldFreeVPN*', '*Microsoft.Advertising.Xaml*'
)
function Remove-AppsTienda {
    param([string[]]$Patrones)
    foreach ($p in $Patrones) {
        $encontradas = @(Get-AppxPackage -Name $p -AllUsers -ErrorAction SilentlyContinue)
        foreach ($app in $encontradas) {
            try {
                Remove-AppxPackage -Package $app.PackageFullName -AllUsers -ErrorAction Stop
                Write-Log "App eliminada: $($app.Name)" 'OK'
            } catch { Write-Log "No se pudo quitar $($app.Name)" 'WARN' }
        }
    }
}

if ($Avanzado) { Remove-AppsTienda -Patrones $appsGenerales }

# ---- B4) Ajustes segun el equipo (disco y memoria) ----
$tipoDisco = Get-TipoDisco
Write-Log "Disco del sistema: $tipoDisco - RAM: $ramGB GB"

# Los juegos, la GPU y el Modo Juego se aplican desde 11-Modo-Juegos.ps1
$cambiosExtras = @(
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' 'AllowCortana' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\Windows Search' 'DisableWebSearch' 1)
)
if ($tipoDisco -eq 'SSD') {
    $pf = 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'
    $cambiosExtras += (RegVal "$pf\PrefetchParameters" 'EnablePrefetcher' 0)
    $cambiosExtras += (RegVal "$pf\PrefetchParameters" 'EnableSuperfetch' 0)
    $cambiosExtras += (RegVal "$pf\PrefetchParameters" 'EnableBoottrace' 0)
    if ($ramGB -ge 8) { $cambiosExtras += (RegVal $pf 'DisablePagingExecutive' 1) }
}
Set-RegistroConBackup -Cambios $cambiosExtras -ArchivoBackup $bkExtras -Resumen

# Disco mecanico: la indexacion de busqueda satura el disco
if ($tipoDisco -eq 'HDD') { Set-ServiciosInicio @(@{ N = 'WSearch'; S = 4 }) }

# Con 8 GB de RAM o mas, la compresion de memoria solo gasta CPU
if ($ramGB -ge 8) {
    try {
        $mm = Get-MMAgent -ErrorAction Stop
        if ($mm.MemoryCompression) {
            if (-not (Test-Path $bkMemoria)) { Set-Content -Path $bkMemoria -Value 'True' -Encoding UTF8 }
            Disable-MMAgent -MemoryCompression -ErrorAction Stop
            Write-Log 'Compresion de memoria desactivada (aplica al reiniciar).' 'OK'
        }
    } catch { Write-Log "No se pudo cambiar la compresion de memoria: $($_.Exception.Message)" 'WARN' }
}

Write-Log 'Ajustes avanzados aplicados. REINICIE el equipo: la baja de procesos se nota despues de reiniciar.' 'OK'
