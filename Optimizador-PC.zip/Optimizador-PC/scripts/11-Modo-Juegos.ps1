﻿# 11-Modo-Juegos.ps1 - Ajustes para obtener mas rendimiento y menos latencia en juegos
# Modo Juego, prioridad de CPU, GPU, red y entrada (el plan de energia es una opcion aparte).
# Reversible con -Revertir. La lista de juegos esta en lista-juegos.txt (se puede editar).
param([switch]$Revertir, [switch]$Silencioso)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
$bk = 'backup_juegos.json'

if ($Revertir) {
    Write-Log '=== REVIRTIENDO MODO JUEGOS ==='
    if (Test-Path (Join-Path $global:OptDatosDir $bk)) { Restore-RegistroDesdeBackup $bk }
    return
}
if (-not (Assert-Admin)) { return }

Write-Log '=== MODO JUEGOS ==='

# 1) Registro: Modo Juego, Game Bar, pantalla completa, GPU, prioridad, entrada
$cambios = @(
    (RegVal 'HKCU:\Software\Microsoft\GameBar' 'AllowAutoGameMode' 1),
    (RegVal 'HKCU:\Software\Microsoft\GameBar' 'AutoGameModeEnabled' 1),
    (RegVal 'HKCU:\Software\Microsoft\GameBar' 'ShowStartupPanel' 0),
    (RegVal 'HKCU:\Software\Microsoft\GameBar' 'UseNexusForGameBarEnabled' 0),
    (RegVal 'HKCU:\System\GameConfigStore' 'GameDVR_Enabled' 0),
    (RegVal 'HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR' 'AppCaptureEnabled' 0),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\GameDVR' 'AllowGameDVR' 0),
    (RegVal 'HKCU:\System\GameConfigStore' 'GameDVR_FSEBehaviorMode' 2),
    (RegVal 'HKCU:\System\GameConfigStore' 'GameDVR_FSEBehavior' 2),
    (RegVal 'HKCU:\System\GameConfigStore' 'GameDVR_HonorUserFSEBehaviorMode' 1),
    (RegVal 'HKCU:\System\GameConfigStore' 'GameDVR_DXGIHonorFSEWindowsCompatible' 1),
    (RegVal 'HKCU:\System\GameConfigStore' 'GameDVR_EFSEFeatureFlags' 0),
    (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' 'HwSchMode' 2),
    (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl' 'Win32PrioritySeparation' 38),
    (RegVal 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' 'PowerThrottlingOff' 1),
    (RegVal 'HKCU:\Control Panel\Mouse' 'MouseSpeed' '0' 'String'),
    (RegVal 'HKCU:\Control Panel\Mouse' 'MouseThreshold1' '0' 'String'),
    (RegVal 'HKCU:\Control Panel\Mouse' 'MouseThreshold2' '0' 'String'),
    (RegVal 'HKCU:\Control Panel\Accessibility\StickyKeys' 'Flags' '506' 'String'),
    (RegVal 'HKCU:\Control Panel\Accessibility\ToggleKeys' 'Flags' '58' 'String'),
    (RegVal 'HKCU:\Control Panel\Accessibility\Keyboard Response' 'Flags' '122' 'String')
)

# 2) Prioridad de CPU para los juegos de lista-juegos.txt
$ifeo = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
foreach ($exe in @(Get-ListaJuegos)) {
    $cambios += (RegVal "$ifeo\$exe\PerfOptions" 'CpuPriorityClass' 6)
}

# 3) Menor latencia de red (sin espera de paquetes pequenos) en los adaptadores con IP
$tcp = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
foreach ($i in @(Get-ChildItem -Path $tcp -ErrorAction SilentlyContinue)) {
    $p = Get-ItemProperty -Path $i.PSPath -ErrorAction SilentlyContinue
    $ip = $p.DhcpIPAddress
    if (-not $ip) { $ip = ($p.IPAddress -join '') }
    if ($ip -and $ip -ne '0.0.0.0') {
        $cambios += (RegVal "$tcp\$($i.PSChildName)" 'TcpAckFrequency' 1)
        $cambios += (RegVal "$tcp\$($i.PSChildName)" 'TCPNoDelay' 1)
    }
}

Set-RegistroConBackup -Cambios $cambios -ArchivoBackup $bk -Resumen
Write-Log 'Modo juegos aplicado. REINICIE el equipo para que todos los cambios queden activos.' 'OK'
