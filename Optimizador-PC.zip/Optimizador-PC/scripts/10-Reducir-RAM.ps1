﻿# 10-Reducir-RAM.ps1 - Reduce el consumo de memoria RAM
# Menos procesos residentes, pestanas inactivas suspendidas en los navegadores, compresion de memoria
# activada y liberacion inmediata de memoria. Reversible con -Revertir.
# -SoloLimpiar: solo libera memoria ahora, sin cambiar ninguna configuracion.
param([switch]$Revertir, [switch]$SoloLimpiar)

. (Join-Path $PSScriptRoot '..\lib\Comun.ps1')
$bk = 'backup_ram.json'
$bkMemoria = Join-Path $global:OptDatosDir 'backup_ajustes_memoria.txt'

if ($Revertir) {
    Write-Log '=== REVIRTIENDO AJUSTES DE RAM ==='
    if (Test-Path (Join-Path $global:OptDatosDir $bk)) { Restore-RegistroDesdeBackup $bk }
    Restore-MemoriaDesdeBackup
    & (Join-Path $PSScriptRoot '09-Reducir-Procesos.ps1') -Revertir
    return
}
if (-not (Assert-Admin)) { return }

$codigo = @'
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

public static class LimpiaMemoria {
    [DllImport("psapi.dll")] static extern int EmptyWorkingSet(IntPtr hProcess);
    [DllImport("ntdll.dll")] static extern uint NtSetSystemInformation(int infoClass, IntPtr info, int length);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool OpenProcessToken(IntPtr process, uint access, out IntPtr token);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool LookupPrivilegeValue(string system, string name, out long luid);
    [DllImport("advapi32.dll", SetLastError = true)] static extern bool AdjustTokenPrivileges(IntPtr token, bool disableAll, ref TokenPrivileges state, int length, IntPtr previous, IntPtr returnLength);

    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    struct TokenPrivileges { public int Count; public long Luid; public int Attributes; }

    static bool Habilitar(string privilegio) {
        IntPtr token;
        if (!OpenProcessToken(Process.GetCurrentProcess().Handle, 0x28, out token)) return false;
        long luid;
        if (!LookupPrivilegeValue(null, privilegio, out luid)) return false;
        TokenPrivileges tp = new TokenPrivileges();
        tp.Count = 1; tp.Luid = luid; tp.Attributes = 2;
        return AdjustTokenPrivileges(token, false, ref tp, 0, IntPtr.Zero, IntPtr.Zero);
    }

    public static int VaciarProcesos() {
        int n = 0;
        foreach (Process p in Process.GetProcesses()) {
            try { if (EmptyWorkingSet(p.Handle) != 0) n++; } catch { }
        }
        return n;
    }

    public static uint PurgarStandby() {
        Habilitar("SeProfileSingleProcessPrivilege");
        IntPtr mem = Marshal.AllocHGlobal(4);
        Marshal.WriteInt32(mem, 4);
        uint r = NtSetSystemInformation(80, mem, 4);
        Marshal.FreeHGlobal(mem);
        return r;
    }
}
'@

function Clear-MemoriaAhora {
    try {
        if (-not ([System.Management.Automation.PSTypeName]'LimpiaMemoria').Type) {
            Add-Type -TypeDefinition $codigo -Language CSharp -ErrorAction Stop
        }
        $libreAntes = [math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory / 1024)
        $n = [LimpiaMemoria]::VaciarProcesos()
        [void][LimpiaMemoria]::PurgarStandby()
        Start-Sleep -Seconds 2
        $libreDespues = [math]::Round((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory / 1024)
        Write-Log "Memoria libre: $libreAntes MB -> $libreDespues MB (procesos ajustados: $n)" 'OK'
    } catch {
        Write-Log "No se pudo liberar memoria: $($_.Exception.Message)" 'WARN'
    }
}

if ($SoloLimpiar) { Clear-MemoriaAhora; return }

Write-Log '=== REDUCIR CONSUMO DE RAM ==='

# 1) Menos procesos residentes (inicio, servicios, widgets, navegadores en segundo plano)
& (Join-Path $PSScriptRoot '09-Reducir-Procesos.ps1')

# 2) Navegadores: las pestanas inactivas se suspenden y liberan memoria
$cambios = @(
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'SleepingTabsEnabled' 1),
    (RegVal 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' 'SleepingTabsTimeout' 300),
    (RegVal 'HKLM:\SOFTWARE\Policies\Google\Chrome' 'HighEfficiencyModeEnabled' 1)
)
Set-RegistroConBackup -Cambios $cambios -ArchivoBackup $bk -Resumen

# 3) Compresion de memoria activada (guarda mas datos en menos RAM)
try {
    $mm = Get-MMAgent -ErrorAction Stop
    if (-not (Test-Path $bkMemoria)) { Set-Content -Path $bkMemoria -Value ([string][bool]$mm.MemoryCompression) -Encoding UTF8 }
    if (-not $mm.MemoryCompression) {
        Enable-MMAgent -MemoryCompression -ErrorAction Stop
        Write-Log 'Compresion de memoria activada (aplica al reiniciar).' 'OK'
    }
} catch { Write-Log "No se pudo cambiar la compresion de memoria: $($_.Exception.Message)" 'WARN' }

# 4) Liberar memoria ahora (efecto inmediato; la RAM se vuelve a usar segun se abren programas)
Clear-MemoriaAhora
Write-Log 'Reinicie el equipo para que todos los cambios de RAM queden activos.' 'OK'
