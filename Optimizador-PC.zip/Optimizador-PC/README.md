﻿# Optimizador de PC (PowerShell)

Kit simple para optimizar equipos con Windows 10/11 con un menú simple y cambios reversibles.

## Cómo se usa

1. Copiá la carpeta completa al equipo del cliente (o a un pendrive).
2. Doble clic en **`Iniciar.bat`** (pide permisos de Administrador solo).
3. Elegí **6) Crear punto de restauración** y luego **1) Optimización completa**.
4. Al terminar, **reiniciá el equipo**: la baja de procesos y el arranque se notan después de reiniciar.

## Menú

El menú muestra los datos del equipo (Windows, CPU, RAM, tipo y espacio de disco), agrupa las opciones por tema, resume cada proceso al terminar (cambios correctos, avisos y errores) y ofrece reiniciar cuando hace falta.

| Opción | Qué hace | Reversible |
|---|---|---|
| 1) Optimización completa | Limpieza, optimizaciones de Windows, modo juegos, red, arranque rápido, reducción de procesos al máximo y reducción del consumo de RAM. Incluye también efectos visuales mínimos, telemetría, servicios y tareas innecesarias, ajustes según disco y RAM, navegadores sin segundo plano y TRIM. Opcionalmente quita las apps preinstaladas de la Tienda | Sí* |
| 2) Optimizaciones de Windows | Efectos visuales mínimos, telemetría y servicios innecesarios, agrupación de `svchost`, prioridad multimedia y de red, Modo Juego y GPU, entrada sin aceleración, sin espera artificial al iniciar programas, sistema de archivos sin escrituras de último acceso, tareas pesadas en segundo plano desactivadas, TRIM/desfragmentación, Explorer sin análisis de carpetas, Edge y Brave sin recomendaciones ni envío de datos, IA de Windows (Recall) apagada, Teredo apagado, IPv4 con prioridad, sin entrega de actualizaciones entre equipos | Sí |
| 3) Plan de energía Maximo rendimiento | Crea el plan con `powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61`, lo llama "Maximo rendimiento" y lo activa. En notebooks pregunta antes (gasta más batería). La optimización completa **no** cambia el plan de energía | Sí |
| 4) Limpieza profunda de disco | Limpieza normal + cachés de aplicaciones + restos de Windows y de actualizaciones + componentes (DISM) + lista de archivos grandes (solo lectura) | No (archivos borrados) |
| 5) Reparar sistema | Salud de discos, DISM, SFC y análisis del disco | - |
| 6) Crear punto de restauración | Crea un punto de restauración de Windows en el momento (ignora el límite de uno cada 24 h) | - |
| 7) Revertir todos los cambios | Deja registro, servicios, tareas, memoria, plan de energía y programas de inicio como estaban | - |

\* Excepto las apps de la Tienda eliminadas (paso opcional), que se reinstalan desde Microsoft Store.

**Única pregunta de la opción 1:** quitar las apps preinstaladas innecesarias (Bing, Solitario, Noticias, etc.). Es el único paso que no se revierte desde el kit. Todo lo demás (efectos visuales, ajustes de disco y memoria según el equipo, navegadores sin segundo plano que mostrarán "administrado por su organización", reducción de procesos y arranque rápido) se aplica siempre y se revierte con la opción 7.

**Lista de juegos:** `lista-juegos.txt` contiene los ejecutables que reciben prioridad alta. Agregá los tuyos, uno por línea.

**Lo que NO se hace a propósito:** desactivar BitLocker, quitar Edge o OneDrive, borrar servicios de Intel, bloquear la Tienda, apagar las notificaciones o IPv6 por completo, desactivar la integridad de memoria (VBS) o las mitigaciones de la CPU (dan algo de rendimiento pero bajan la seguridad), limpiadores de registro, "liberadores de RAM" residentes y otros trucos sin efecto real.

## Ejecutar con un solo comando (repositorio privado)

Para abrir PC Optimizer desde cualquier PC con un comando de PowerShell, manteniendo el código privado:

1. Creá un repositorio **privado** en GitHub y subí todo el contenido de esta carpeta (incluido `Instalar.ps1`).
2. Abrí `Instalar.ps1` y cambiá `$Usuario` y `$Repo` por los tuyos. Guardalo como texto simple, sin BOM.
3. Creá un **token de solo lectura**: GitHub > Settings > Developer settings > Personal access tokens > Fine-grained tokens > Generate new token.
   - *Repository access*: Only select repositories, y elegí solo este repositorio.
   - *Permissions*: Repository permissions > **Contents: Read-only**.
   - *Expiration*: elegí un vencimiento (por ejemplo 30 o 90 días).
4. Desde la PC del cliente, abrí PowerShell y ejecutá (con tu token, usuario y repositorio):

```
$Token='github_pat_XXXX'; irm -Headers @{Authorization="Bearer $Token";Accept='application/vnd.github.raw'} 'https://api.github.com/repos/TU-USUARIO/TU-REPOSITORIO/contents/Instalar.ps1?ref=main' | iex
```

El comando pide permisos de Administrador, descarga la última versión, la instala en `C:\ProgramData\PCOptimizer` (conserva los backups para revertir) y abre el menú. El token no se guarda en el equipo del cliente.

**Buenas prácticas con el token**
- Creá **un token por cliente**: si hay un problema, revocás solo ese.
- Quien tenga el comando puede leer el repositorio. Dalo solo a quienes confiás y usá vencimientos cortos.
- Activá la verificación en dos pasos en tu cuenta de GitHub.
- Para actualizar, solo subí los cambios al repositorio: el próximo comando descarga la versión nueva.

## Estructura

| Archivo | Función |
|---|---|
| `Iniciar.bat` | Lanzador con elevación a Administrador |
| `Instalar.ps1` | Instalador para ejecutar todo con un comando de PowerShell |
| `Menu.ps1` | Menú principal |
| `lista-juegos.txt` | Juegos con prioridad de CPU (editable) |
| `lib/Comun.ps1` | Funciones comunes: mensajes, backups, servicios, inicio |
| `scripts/01-Limpieza.ps1` | Temporales, cachés de navegadores, Windows Update, miniaturas, DNS |
| `scripts/02-Rendimiento.ps1` | Plan de energía, efectos, segundo plano, TRIM/desfragmentación |
| `scripts/03-Inicio.ps1` | Programas de inicio (lista numerada) |
| `scripts/04-Red.ps1` | DNS, latencia, pila de red |
| `scripts/05-Reparacion.ps1` | DISM, SFC, disco |
| `scripts/08-Ajustes-Avanzados.ps1` | Servicios, tareas, telemetría, `svchost`, efectos visuales y ajustes según disco/RAM |
| `scripts/09-Reducir-Procesos.ps1` | Modo reducir procesos |
| `scripts/10-Reducir-RAM.ps1` | Modo reducir RAM |
| `scripts/11-Modo-Juegos.ps1` | Modo juegos |
| `scripts/12-Arranque-Rapido.ps1` | Modo arranque rápido |
| `scripts/13-Limpieza-Profunda.ps1` | Limpieza profunda |
| `scripts/15-Plan-Energia.ps1` | Plan de energía Maximo rendimiento |
| `scripts/14-Optimizaciones-Windows.ps1` | Optimizaciones de Windows (reúne 02, 08, 11 y ajustes propios) |

La carpeta `datos/` se crea sola y guarda los backups necesarios para revertir. No se guarda ningún registro ni informe.

## Seguridad

- Antes de optimizar, usá la opción 6 para crear un punto de restauración (no se crea solo).
- Cada modo guarda el valor original y se revierte con la opción 7.
- No desactiva Windows Defender, Windows Update ni el firewall, no toca las mitigaciones de seguridad de la CPU, no elimina Edge ni OneDrive, no toca antivirus, audio ni touchpad en el inicio, y no borra contraseñas ni cookies.
- La limpieza profunda solo elimina Windows.old si el cliente lo confirma (no se puede deshacer).
- **Probalo primero en tu propia PC o en una máquina virtual** antes de usarlo con clientes.

## Para venderlo como servicio

- **Paquetes posibles:** básico (optimizaciones de Windows + limpieza), completo (opción 1) y mantenimiento mensual.
- **Pedí conformidad** del cliente antes de intervenir y avisá que hay que reiniciar.
- No prometas milagros: con HDD viejo o poca RAM, recomendá SSD o más memoria (upsell honesto).

## Requisitos

Windows 10/11, PowerShell 5.1 (incluido) y permisos de Administrador.
