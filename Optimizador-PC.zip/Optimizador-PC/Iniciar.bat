@echo off
title PC Optimizer
rem Lanzador: solicita permisos de Administrador y abre el menu de PC Optimizer
cd /d "%~dp0"
where powershell >nul 2>&1
if %errorlevel% neq 0 (
    echo No se encontro Windows PowerShell. Este programa requiere Windows 10 u 11.
    pause
    exit /b 1
)
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo Solicitando permisos de Administrador...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Menu.ps1"
if %errorlevel% neq 0 pause
